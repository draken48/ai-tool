import React, { useState, useMemo } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import type { Category, InsertCategory } from '@shared/schema';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { CATEGORY_ICONS } from '@/lib/constants';

type CatNode = Category & { children: CatNode[] };

export default function CategoriesPage() {
  const { token } = useAuth();
  const { toast } = useToast();
  const { data: categories = [] } = useQuery<Category[]>({ queryKey: ['/api/categories'], enabled: !!token });

  const [name, setName] = useState('');
  const [color, setColor] = useState('#888888');
  const [icon, setIcon] = useState<string>('MoreHorizontal');
  const [parent, setParent] = useState<string | undefined>(undefined);

  const [editing, setEditing] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editParent, setEditParent] = useState<string | undefined>(undefined);
  const [editColor, setEditColor] = useState('#888888');
  const [editIcon, setEditIcon] = useState<string>('MoreHorizontal');

  const create = useMutation({ mutationFn: (c: InsertCategory) => apiRequest('POST', '/api/categories', c, token), onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['/api/categories'] }); setName(''); setColor('#888888'); setIcon('MoreHorizontal'); setParent(undefined); } });
  const remove = useMutation({ mutationFn: (id: string) => apiRequest('DELETE', `/api/categories/${id}`, undefined, token), onSuccess: () => queryClient.invalidateQueries({ queryKey: ['/api/categories'] }) });

  const roots = useMemo(() => buildTree(categories), [categories]);

  function buildTree(items: Category[]): CatNode[] {
    const map = new Map<string, CatNode>();
    items.forEach(i => map.set(i.id, { ...(i as any), children: [] } as CatNode));
    const roots: CatNode[] = [];
    for (const node of Array.from(map.values())) {
      if (node.parentId && map.has(node.parentId)) {
        map.get(node.parentId)!.children.push(node);
      } else {
        roots.push(node);
      }
    }
    return roots;
  }

  async function reparent(srcId: string, targetParentId: string | null) {
    try {
      await apiRequest('PATCH', `/api/categories/${srcId}`, { parentId: targetParentId });
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
    } catch (err) {
      toast({ title: 'Error', description: String(err) });
    }
  }

  // helper: find node by id in the tree
  function findNodeById(list: CatNode[], id: string): CatNode | null {
    for (const n of list) {
      if (n.id === id) return n;
      const found = findNodeById(n.children || [], id);
      if (found) return found;
    }
    return null;
  }

  // helper: is `possibleDescendantId` inside subtree rooted at `nodeId`?
  function isDescendant(rootList: CatNode[], nodeId: string, possibleDescendantId: string): boolean {
    const node = findNodeById(rootList, nodeId);
    if (!node) return false;
    // DFS
    const stack: CatNode[] = [...(node.children || [])];
    while (stack.length) {
      const cur = stack.pop()!;
      if (cur.id === possibleDescendantId) return true;
      if (cur.children && cur.children.length) stack.push(...cur.children);
    }
    return false;
  }

  function TreeNode({ node, level }: { node: CatNode; level: number }) {
    return (
      <div style={{ marginLeft: level * 16 }}>
        <Card
          className="p-3 my-1"
          draggable
          onDragStart={(e) => { e.dataTransfer.setData('text/plain', node.id); }}
          onDragOver={(e) => e.preventDefault()}
          onDrop={async (e) => {
            e.stopPropagation();
            const src = e.dataTransfer.getData('text/plain');
            if (!src || src === node.id) return;
            // client-side prevent moving into own descendant
            if (isDescendant(roots, src, node.id)) {
              toast({ title: 'Invalid move', description: 'Cannot move a category into one of its own subcategories.' });
              return;
            }
            await reparent(src, node.id);
          }}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div style={{ backgroundColor: node.color + '20' }} className="p-2 rounded"><div style={{ color: node.color }}>{node.icon}</div></div>
              <div>
                <div className="font-medium">{node.name}</div>
                <div className="text-sm text-muted-foreground">{node.id}</div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button variant="ghost" onClick={() => { navigator.clipboard?.writeText(node.id); }}>Copy ID</Button>
              <Button variant="ghost" onClick={() => { setEditing(node.id); setEditName(node.name); setEditParent(node.parentId || undefined); setEditColor(node.color || '#888888'); setEditIcon(node.icon || 'MoreHorizontal'); }}>Edit</Button>
              <Button variant="destructive" onClick={() => remove.mutate(node.id)}>Delete</Button>
            </div>
          </div>

          {editing === node.id && (
            <div className="mt-2 flex gap-2">
              <Input value={editName} onChange={e => setEditName(e.target.value)} />
              <input aria-label="edit-color" type="color" value={editColor} onChange={e => setEditColor(e.target.value)} />
              <Select value={editIcon} onValueChange={(v) => setEditIcon(v)}>
                <SelectTrigger className="w-40"><SelectValue placeholder="Icon" /></SelectTrigger>
                <SelectContent>{Object.keys(CATEGORY_ICONS).map(k => <SelectItem key={k} value={k}>{k}</SelectItem>)}</SelectContent>
              </Select>
              <Select value={editParent ?? ''} onValueChange={(v) => setEditParent(v || undefined)}>
                <SelectTrigger className="w-40"><SelectValue placeholder="Parent (optional)" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="">None</SelectItem>
                  {categories.filter(c => c.id !== node.id).map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
              <Button onClick={() => {
                if (!editName.trim()) { toast({ title: 'Name required' }); return; }
                apiRequest('PATCH', `/api/categories/${node.id}`, { name: editName.trim(), parentId: editParent || undefined, color: editColor, icon: editIcon }).then(() => { queryClient.invalidateQueries({ queryKey: ['/api/categories'] }); setEditing(null); });
              }}>Save</Button>
              <Button variant="ghost" onClick={() => setEditing(null)}>Cancel</Button>
            </div>
          )}

          {node.children && node.children.length > 0 && node.children.map(child => <TreeNode key={child.id} node={child} level={level + 1} />)}
        </Card>
      </div>
    );
  }

  return (
    <div>
      <h2 className="text-2xl font-heading font-semibold mb-4">Categories</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-4">
          <h3 className="font-medium mb-2">Add category</h3>
          <div className="flex gap-2 items-center">
            <Input value={name} onChange={e => setName(e.target.value)} placeholder="Category name" />
            <input aria-label="color" type="color" value={color} onChange={e => setColor(e.target.value)} className="w-10 h-8" />
            <Select value={icon} onValueChange={(v) => setIcon(v)}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Icon" />
              </SelectTrigger>
              <SelectContent>
                {Object.keys(CATEGORY_ICONS).map(k => <SelectItem key={k} value={k}>{k}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={parent ?? ''} onValueChange={(v) => setParent(v || undefined)}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Parent (optional)" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">None</SelectItem>
                {categories.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button onClick={() => {
              if (!name.trim()) { toast({ title: 'Name required' }); return; }
              create.mutate({ name: name.trim(), icon, color, parentId: parent || undefined } as any);
            }}>Add</Button>
          </div>
        </Card>

        <div className="md:col-span-2">
          <div className="space-y-2">
            <div className="p-2 rounded border border-dashed text-sm text-muted-foreground" onDragOver={(e) => e.preventDefault()} onDrop={async (e) => {
              const src = e.dataTransfer.getData('text/plain');
              if (!src) return; await reparent(src, null);
            }}>Drop here to make root</div>
            {roots.map(r => <TreeNode key={r.id} node={r} level={0} />)}
          </div>
        </div>
      </div>
    </div>
  );
}
