import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/components/theme-provider";
import { Moon, Sun, Info, Download } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { DataExportImport } from "@/components/DataExportImport";
import { CurrencyConverter } from "@/components/CurrencyConverter";

export default function Settings() {
  const { theme, toggleTheme } = useTheme();

  return (
    <div className="space-y-6" data-testid="container-settings">
      <div>
        <h1 className="text-3xl font-heading font-bold text-foreground mb-2" data-testid="text-settings-title">
          Settings
        </h1>
        <p className="text-muted-foreground" data-testid="text-settings-subtitle">
          Customize your Finote experience
        </p>
      </div>

      <Card className="p-6">
        <h2 className="text-xl font-heading font-semibold text-foreground mb-4">
          Appearance
        </h2>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {theme === 'dark' ? (
              <Moon className="h-5 w-5 text-muted-foreground" />
            ) : (
              <Sun className="h-5 w-5 text-muted-foreground" />
            )}
            <div>
              <Label htmlFor="theme-toggle" className="text-base font-medium">
                Dark Mode
              </Label>
              <p className="text-sm text-muted-foreground">
                Switch between light and dark theme
              </p>
            </div>
          </div>
          <Switch
            id="theme-toggle"
            checked={theme === 'dark'}
            onCheckedChange={toggleTheme}
            data-testid="switch-theme"
          />
        </div>
      </Card>

      <DataExportImport />

      <CurrencyConverter />

      <Card className="p-6">
        <h2 className="text-xl font-heading font-semibold text-foreground mb-4">
          About Finote
        </h2>
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <Info className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm text-muted-foreground mb-2">
                Finote is your smart expense tracker designed for the Indian market. 
                Track expenses in Indian Rupees, manage budgets, and stay on top of your recurring payments.
              </p>
              <p className="text-sm text-muted-foreground">
                Version 2.0 - Progressive Web App
              </p>
            </div>
          </div>

          <Separator />

          <div>
            <h3 className="text-base font-medium text-foreground mb-2">Features</h3>
            <ul className="text-sm text-muted-foreground space-y-1 ml-4 list-disc">
              <li>Add, edit, and delete expenses with custom categories</li>
              <li>Track recurring payments and subscriptions</li>
              <li>Set budgets with smart alerts</li>
              <li>Beautiful charts and analytics</li>
              <li>Export data to CSV</li>
              <li>Offline-first design</li>
              <li>Install as app on any device</li>
            </ul>
          </div>

          <Separator />

          <div>
            <h3 className="text-base font-medium text-foreground mb-2">Installation</h3>
            <p className="text-sm text-muted-foreground mb-2">
              Install Finote on your device for quick access:
            </p>
            <ul className="text-sm text-muted-foreground space-y-1 ml-4 list-disc">
              <li>Mobile: Tap the share button and select "Add to Home Screen"</li>
              <li>Desktop: Look for the install icon in your browser's address bar</li>
            </ul>
          </div>
        </div>
      </Card>
    </div>
  );
}
