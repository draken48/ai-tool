import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Pencil, Trash2, Play, Pause, Calendar } from "lucide-react";
import { formatCurrency, formatDate } from "@/lib/utils";
import type { RecurringPayment, Category } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { RecurringDialog } from "@/components/recurring-dialog";
import { CATEGORY_ICONS } from "@/lib/constants";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";

export default function Recurring() {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingPayment, setEditingPayment] = useState<RecurringPayment | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [paymentToDelete, setPaymentToDelete] = useState<string | null>(null);

  const { data: recurringPayments = [], isLoading } = useQuery<RecurringPayment[]>({
    queryKey: ['/api/recurring-payments'],
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest('DELETE', `/api/recurring-payments/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/recurring-payments'] });
      toast({
        title: "Recurring payment deleted",
        description: "The recurring payment has been removed successfully.",
      });
      setDeleteDialogOpen(false);
      setPaymentToDelete(null);
    },
  });

  const toggleActiveMutation = useMutation({
    mutationFn: ({ id, isActive }: { id: string; isActive: boolean }) => 
      apiRequest('PATCH', `/api/recurring-payments/${id}`, { isActive }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/recurring-payments'] });
      toast({
        title: "Status updated",
        description: "Recurring payment status has been updated.",
      });
    },
  });

  const handleEdit = (payment: RecurringPayment) => {
    setEditingPayment(payment);
    setDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    setPaymentToDelete(id);
    setDeleteDialogOpen(true);
  };

  const handleToggleActive = (payment: RecurringPayment) => {
    toggleActiveMutation.mutate({ id: payment.id, isActive: !payment.isActive });
  };

  const activePayments = recurringPayments.filter(p => p.isActive);
  const inactivePayments = recurringPayments.filter(p => !p.isActive);

  const totalMonthly = activePayments
    .filter(p => p.frequency === 'monthly')
    .reduce((sum, p) => sum + parseFloat(p.amount), 0);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground" data-testid="text-loading">Loading recurring payments...</p>
        </div>
      </div>
    );
  }

  const renderPaymentCard = (payment: RecurringPayment) => {
    const category = categories.find(c => c.id === payment.categoryId);
    const IconComponent = category ? CATEGORY_ICONS[category.icon] : null;
    const now = new Date();
    const nextDue = new Date(payment.nextDue);
    const daysUntil = Math.ceil((nextDue.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    const isOverdue = daysUntil < 0;

    return (
      <Card 
        key={payment.id} 
        className="p-6 hover-elevate transition-all duration-200"
        data-testid={`recurring-item-${payment.id}`}
      >
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3 flex-1 min-w-0">
            {category && IconComponent && (
              <div
                className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                style={{ backgroundColor: category.color + '20' }}
              >
                <IconComponent className="h-6 w-6" style={{ color: category.color }} />
              </div>
            )}
            <div className="flex-1 min-w-0">
              <h3 className="text-lg font-heading font-semibold text-foreground truncate" data-testid={`text-recurring-description-${payment.id}`}>
                {payment.description}
              </h3>
              <div className="flex items-center gap-2 flex-wrap mt-1">
                {category && (
                  <span className="text-xs px-2 py-0.5 rounded-full" style={{ 
                    backgroundColor: category.color + '20',
                    color: category.color
                  }}>
                    {category.name}
                  </span>
                )}
                <Badge variant={payment.isActive ? "default" : "secondary"} className="text-xs">
                  {payment.isActive ? "Active" : "Paused"}
                </Badge>
              </div>
            </div>
          </div>
          <div className="flex gap-1 ml-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleToggleActive(payment)}
              data-testid={`button-toggle-${payment.id}`}
            >
              {payment.isActive ? (
                <Pause className="h-4 w-4" />
              ) : (
                <Play className="h-4 w-4" />
              )}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleEdit(payment)}
              data-testid={`button-edit-${payment.id}`}
            >
              <Pencil className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleDelete(payment.id)}
              data-testid={`button-delete-${payment.id}`}
            >
              <Trash2 className="h-4 w-4 text-destructive" />
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground mb-1">Amount</p>
            <p className="text-2xl font-bold font-heading tabular-nums text-destructive" data-testid={`text-recurring-amount-${payment.id}`}>
              {formatCurrency(parseFloat(payment.amount))}
            </p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground mb-1">Frequency</p>
            <p className="text-lg font-semibold capitalize text-foreground">
              {payment.frequency}
            </p>
          </div>
        </div>

        <div className="mt-4 p-3 rounded-lg bg-muted/50">
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">
                {isOverdue ? 'Overdue' : 'Next due'}
              </p>
              <p className={`text-sm ${isOverdue ? 'text-destructive' : 'text-muted-foreground'}`}>
                {formatDate(payment.nextDue)}
                {!isOverdue && daysUntil > 0 && ` (in ${daysUntil} day${daysUntil > 1 ? 's' : ''})`}
                {!isOverdue && daysUntil === 0 && ' (today)'}
              </p>
            </div>
          </div>
        </div>

        {payment.notes && (
          <p className="text-sm text-muted-foreground mt-3">
            {payment.notes}
          </p>
        )}
      </Card>
    );
  };

  return (
    <div className="space-y-6" data-testid="container-recurring">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground mb-2" data-testid="text-recurring-title">
            Recurring Payments
          </h1>
          <p className="text-muted-foreground" data-testid="text-recurring-subtitle">
            Manage your subscriptions and regular expenses
          </p>
        </div>
        <Button onClick={() => { setEditingPayment(null); setDialogOpen(true); }} data-testid="button-add-recurring">
          <Plus className="h-4 w-4 mr-2" />
          Add Recurring Payment
        </Button>
      </div>

      {totalMonthly > 0 && (
        <Card className="p-6 bg-gradient-to-br from-primary/10 to-chart-2/10 border-primary/20">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground mb-1">
                Total Monthly Recurring
              </p>
              <p className="text-4xl font-bold font-heading tabular-nums text-foreground" data-testid="text-total-monthly">
                {formatCurrency(totalMonthly)}
              </p>
            </div>
            <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center">
              <Calendar className="h-8 w-8 text-primary" />
            </div>
          </div>
        </Card>
      )}

      {recurringPayments.length === 0 ? (
        <Card className="p-12">
          <div className="text-center">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Calendar className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2" data-testid="text-no-recurring">
              No recurring payments
            </h3>
            <p className="text-muted-foreground mb-4">
              Add subscriptions and recurring expenses to track them automatically
            </p>
            <Button onClick={() => { setEditingPayment(null); setDialogOpen(true); }} data-testid="button-add-first-recurring">
              <Plus className="h-4 w-4 mr-2" />
              Add Recurring Payment
            </Button>
          </div>
        </Card>
      ) : (
        <>
          {activePayments.length > 0 && (
            <div>
              <h2 className="text-xl font-heading font-semibold text-foreground mb-4">
                Active ({activePayments.length})
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {activePayments.map(renderPaymentCard)}
              </div>
            </div>
          )}

          {inactivePayments.length > 0 && (
            <div>
              <h2 className="text-xl font-heading font-semibold text-foreground mb-4">
                Paused ({inactivePayments.length})
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {inactivePayments.map(renderPaymentCard)}
              </div>
            </div>
          )}
        </>
      )}

      <RecurringDialog
        open={dialogOpen}
        onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) setEditingPayment(null);
        }}
        payment={editingPayment}
        categories={categories}
      />

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete recurring payment?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the recurring payment.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => paymentToDelete && deleteMutation.mutate(paymentToDelete)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
