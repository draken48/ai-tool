import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Pencil, Trash2, AlertTriangle, TrendingUp } from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import type { Budget, Category, Expense } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { BudgetDialog } from "@/components/budget-dialog";
import { Progress } from "@/components/ui/progress";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function Budgets() {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingBudget, setEditingBudget] = useState<Budget | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [budgetToDelete, setBudgetToDelete] = useState<string | null>(null);

  const { data: budgets = [], isLoading } = useQuery<Budget[]>({
    queryKey: ['/api/budgets'],
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  const { data: expenses = [] } = useQuery<Expense[]>({
    queryKey: ['/api/expenses'],
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest('DELETE', `/api/budgets/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/budgets'] });
      toast({
        title: "Budget deleted",
        description: "The budget has been removed successfully.",
      });
      setDeleteDialogOpen(false);
      setBudgetToDelete(null);
    },
  });

  const handleEdit = (budget: Budget) => {
    setEditingBudget(budget);
    setDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    setBudgetToDelete(id);
    setDeleteDialogOpen(true);
  };

  const getBudgetSpent = (budget: Budget) => {
    const budgetExpenses = expenses.filter(e => {
      const eDate = new Date(e.date);
      const start = new Date(budget.startDate);
      const end = new Date(budget.endDate);
      
      const inDateRange = eDate >= start && eDate <= end;
      const matchesCategory = budget.isTotal || e.categoryId === budget.categoryId;
      
      return inDateRange && matchesCategory;
    });

    return budgetExpenses.reduce((sum, e) => sum + parseFloat(e.amount), 0);
  };

  const budgetsWithStatus = budgets.map(budget => {
    const spent = getBudgetSpent(budget);
    const budgetAmount = parseFloat(budget.amount);
    const percentage = (spent / budgetAmount) * 100;
    const remaining = budgetAmount - spent;
    
    let status: 'safe' | 'warning' | 'danger' = 'safe';
    if (percentage >= 100) {
      status = 'danger';
    } else if (percentage >= budget.alertThreshold) {
      status = 'warning';
    }

    return {
      ...budget,
      spent,
      percentage: Math.min(percentage, 100),
      remaining,
      status,
    };
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground" data-testid="text-loading">Loading budgets...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6" data-testid="container-budgets">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground mb-2" data-testid="text-budgets-title">
            Budgets
          </h1>
          <p className="text-muted-foreground" data-testid="text-budgets-subtitle">
            Set and track your spending limits
          </p>
        </div>
        <Button onClick={() => { setEditingBudget(null); setDialogOpen(true); }} data-testid="button-add-budget">
          <Plus className="h-4 w-4 mr-2" />
          Add Budget
        </Button>
      </div>

      {budgets.length === 0 ? (
        <Card className="p-12">
          <div className="text-center">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <TrendingUp className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2" data-testid="text-no-budgets">
              No budgets set
            </h3>
            <p className="text-muted-foreground mb-4">
              Create budgets to keep your spending under control
            </p>
            <Button onClick={() => { setEditingBudget(null); setDialogOpen(true); }} data-testid="button-add-first-budget">
              <Plus className="h-4 w-4 mr-2" />
              Add Budget
            </Button>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {budgetsWithStatus.map((budget) => {
            const category = budget.categoryId 
              ? categories.find(c => c.id === budget.categoryId)
              : null;

            const progressColor = 
              budget.status === 'danger' ? 'bg-destructive' :
              budget.status === 'warning' ? 'bg-chart-5' :
              'bg-primary';

            return (
              <Card key={budget.id} className="p-6 hover-elevate transition-all duration-200" data-testid={`budget-item-${budget.id}`}>
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-heading font-semibold text-foreground mb-1" data-testid={`text-budget-name-${budget.id}`}>
                      {budget.isTotal ? 'Total Budget' : category?.name || 'Unknown Category'}
                    </h3>
                    <p className="text-sm text-muted-foreground capitalize">
                      {budget.period}
                    </p>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleEdit(budget)}
                      data-testid={`button-edit-${budget.id}`}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(budget.id)}
                      data-testid={`button-delete-${budget.id}`}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-muted-foreground">Spent</span>
                      <span className="text-sm font-bold tabular-nums text-foreground">
                        {budget.percentage.toFixed(0)}%
                      </span>
                    </div>
                    <Progress value={budget.percentage} className={`h-3 ${progressColor}`} />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Spent</p>
                      <p className="text-xl font-bold font-heading tabular-nums text-destructive" data-testid={`text-budget-spent-${budget.id}`}>
                        {formatCurrency(budget.spent)}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">Budget</p>
                      <p className="text-xl font-bold font-heading tabular-nums text-foreground" data-testid={`text-budget-amount-${budget.id}`}>
                        {formatCurrency(parseFloat(budget.amount))}
                      </p>
                    </div>
                  </div>

                  {budget.status !== 'safe' && (
                    <div className={`flex items-center gap-2 p-3 rounded-lg ${
                      budget.status === 'danger' 
                        ? 'bg-destructive/10 border border-destructive/20' 
                        : 'bg-chart-5/10 border border-chart-5/20'
                    }`}>
                      <AlertTriangle className={`h-4 w-4 flex-shrink-0 ${
                        budget.status === 'danger' ? 'text-destructive' : 'text-chart-5'
                      }`} />
                      <p className={`text-sm font-medium ${
                        budget.status === 'danger' ? 'text-destructive' : 'text-chart-5'
                      }`}>
                        {budget.status === 'danger' 
                          ? `Over budget by ${formatCurrency(Math.abs(budget.remaining))}`
                          : `${formatCurrency(budget.remaining)} remaining (${budget.alertThreshold}% threshold reached)`
                        }
                      </p>
                    </div>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <BudgetDialog
        open={dialogOpen}
        onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) setEditingBudget(null);
        }}
        budget={editingBudget}
        categories={categories}
      />

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete budget?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the budget.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => budgetToDelete && deleteMutation.mutate(budgetToDelete)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
