import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { formatCurrency, formatDate, getMonthName } from "@/lib/utils";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, LineChart, Line, Legend } from 'recharts';
import { TrendingUp, TrendingDown, Wallet, CreditCard, AlertTriangle, Calendar } from "lucide-react";
import type { Expense, Category, Budget, RecurringPayment } from "@shared/schema";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function Dashboard() {
  const { data: expenses = [], isLoading: expensesLoading } = useQuery<Expense[]>({
    queryKey: ['/api/expenses'],
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  const { data: budgets = [] } = useQuery<Budget[]>({
    queryKey: ['/api/budgets'],
  });

  const { data: recurringPayments = [] } = useQuery<RecurringPayment[]>({
    queryKey: ['/api/recurring-payments'],
  });

  const now = new Date();
  const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);

  const thisMonthExpenses = expenses.filter(e => {
    const date = new Date(e.date);
    return date >= thisMonth && date <= nextMonth;
  });

  const totalThisMonth = thisMonthExpenses.reduce((sum, e) => sum + parseFloat(e.amount), 0);

  const last7Days = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const last7DaysExpenses = expenses.filter(e => new Date(e.date) >= last7Days);
  const totalLast7Days = last7DaysExpenses.reduce((sum, e) => sum + parseFloat(e.amount), 0);

  const categorySpending = categories.map(cat => ({
    name: cat.name,
    value: thisMonthExpenses
      .filter(e => e.categoryId === cat.id)
      .reduce((sum, e) => sum + parseFloat(e.amount), 0),
    color: cat.color,
  })).filter(c => c.value > 0);

  const last30Days = Array.from({ length: 30 }, (_, i) => {
    const date = new Date(now.getTime() - (29 - i) * 24 * 60 * 60 * 1000);
    const dayExpenses = expenses.filter(e => {
      const eDate = new Date(e.date);
      return eDate.toDateString() === date.toDateString();
    });
    return {
      date: date.getDate() + ' ' + date.toLocaleDateString('en-IN', { month: 'short' }),
      amount: dayExpenses.reduce((sum, e) => sum + parseFloat(e.amount), 0),
    };
  });

  const budgetAlerts = budgets.filter(budget => {
    const budgetExpenses = budget.isTotal
      ? thisMonthExpenses
      : thisMonthExpenses.filter(e => e.categoryId === budget.categoryId);
    const spent = budgetExpenses.reduce((sum, e) => sum + parseFloat(e.amount), 0);
    const percentage = (spent / parseFloat(budget.amount)) * 100;
    return percentage >= budget.alertThreshold;
  });

  const upcomingRecurring = recurringPayments
    .filter(rp => rp.isActive && new Date(rp.nextDue) <= new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000))
    .sort((a, b) => new Date(a.nextDue).getTime() - new Date(b.nextDue).getTime())
    .slice(0, 3);

  const previousMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const previousMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0);
  const previousMonthExpenses = expenses.filter(e => {
    const date = new Date(e.date);
    return date >= previousMonthStart && date <= previousMonthEnd;
  });
  const totalPreviousMonth = previousMonthExpenses.reduce((sum, e) => sum + parseFloat(e.amount), 0);
  const monthChange = totalPreviousMonth > 0 
    ? ((totalThisMonth - totalPreviousMonth) / totalPreviousMonth) * 100 
    : 0;

  if (expensesLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground" data-testid="text-loading">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6" data-testid="container-dashboard">
      <div>
        <h1 className="text-3xl font-heading font-bold text-foreground mb-2" data-testid="text-dashboard-title">
          Financial Overview
        </h1>
        <p className="text-muted-foreground" data-testid="text-dashboard-subtitle">
          {getMonthName(now)}
        </p>
      </div>

      {budgetAlerts.length > 0 && (
        <Alert className="border-destructive/50 bg-destructive/10" data-testid="alert-budget-warning">
          <AlertTriangle className="h-4 w-4 text-destructive" />
          <AlertDescription className="text-destructive">
            <strong>Budget Alert!</strong> You've exceeded {budgetAlerts.length} budget{budgetAlerts.length > 1 ? 's' : ''} this month.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6 hover-elevate transition-all duration-200" data-testid="card-total-month">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm font-medium text-muted-foreground">This Month</p>
            <Wallet className="h-5 w-5 text-primary" />
          </div>
          <p className="text-3xl font-bold font-heading text-foreground tabular-nums" data-testid="text-total-month">
            {formatCurrency(totalThisMonth)}
          </p>
          {totalPreviousMonth > 0 && (
            <div className="flex items-center gap-1 mt-2">
              {monthChange > 0 ? (
                <TrendingUp className="h-4 w-4 text-destructive" />
              ) : (
                <TrendingDown className="h-4 w-4 text-primary" />
              )}
              <span className={`text-sm font-medium ${monthChange > 0 ? 'text-destructive' : 'text-primary'}`}>
                {Math.abs(monthChange).toFixed(1)}% from last month
              </span>
            </div>
          )}
        </Card>

        <Card className="p-6 hover-elevate transition-all duration-200" data-testid="card-week">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm font-medium text-muted-foreground">Last 7 Days</p>
            <Calendar className="h-5 w-5 text-chart-2" />
          </div>
          <p className="text-3xl font-bold font-heading text-foreground tabular-nums" data-testid="text-total-week">
            {formatCurrency(totalLast7Days)}
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            {last7DaysExpenses.length} transaction{last7DaysExpenses.length !== 1 ? 's' : ''}
          </p>
        </Card>

        <Card className="p-6 hover-elevate transition-all duration-200" data-testid="card-categories">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm font-medium text-muted-foreground">Categories</p>
            <CreditCard className="h-5 w-5 text-chart-3" />
          </div>
          <p className="text-3xl font-bold font-heading text-foreground tabular-nums" data-testid="text-categories-count">
            {categorySpending.length}
          </p>
          <p className="text-sm text-muted-foreground mt-2">Active this month</p>
        </Card>

        <Card className="p-6 hover-elevate transition-all duration-200" data-testid="card-recurring">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm font-medium text-muted-foreground">Recurring</p>
            <AlertTriangle className="h-5 w-5 text-chart-4" />
          </div>
          <p className="text-3xl font-bold font-heading text-foreground tabular-nums" data-testid="text-recurring-count">
            {upcomingRecurring.length}
          </p>
          <p className="text-sm text-muted-foreground mt-2">Due in 7 days</p>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6" data-testid="card-chart-category">
          <h3 className="text-lg font-heading font-semibold mb-4 text-foreground">Spending by Category</h3>
          {categorySpending.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={categorySpending}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {categorySpending.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: any) => formatCurrency(value)} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-[300px] text-muted-foreground">
              <p data-testid="text-no-category-data">No expenses yet this month</p>
            </div>
          )}
        </Card>

        <Card className="p-6" data-testid="card-chart-trend">
          <h3 className="text-lg font-heading font-semibold mb-4 text-foreground">30-Day Spending Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={last30Days}>
              <XAxis 
                dataKey="date" 
                tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                tickLine={false}
              />
              <YAxis 
                tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                tickLine={false}
                tickFormatter={(value) => `₹${value}`}
              />
              <Tooltip 
                formatter={(value: any) => formatCurrency(value)}
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                }}
              />
              <Line 
                type="monotone" 
                dataKey="amount" 
                stroke="hsl(var(--primary))" 
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--primary))', r: 3 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {upcomingRecurring.length > 0 && (
        <Card className="p-6" data-testid="card-upcoming-recurring">
          <h3 className="text-lg font-heading font-semibold mb-4 text-foreground">Upcoming Recurring Payments</h3>
          <div className="space-y-3">
            {upcomingRecurring.map((payment) => {
              const category = categories.find(c => c.id === payment.categoryId);
              const daysUntil = Math.ceil((new Date(payment.nextDue).getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
              
              return (
                <div 
                  key={payment.id} 
                  className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover-elevate"
                  data-testid={`recurring-item-${payment.id}`}
                >
                  <div className="flex items-center gap-3">
                    {category && (
                      <div 
                        className="w-10 h-10 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: category.color + '20' }}
                      >
                        <div style={{ color: category.color }}>
                          <CreditCard className="h-5 w-5" />
                        </div>
                      </div>
                    )}
                    <div>
                      <p className="font-medium text-foreground">{payment.description}</p>
                      <p className="text-sm text-muted-foreground">
                        Due {daysUntil === 0 ? 'today' : `in ${daysUntil} day${daysUntil > 1 ? 's' : ''}`}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold tabular-nums text-destructive">{formatCurrency(parseFloat(payment.amount))}</p>
                    <p className="text-sm text-muted-foreground capitalize">{payment.frequency}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      )}
    </div>
  );
}
