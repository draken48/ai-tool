import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Pencil, Trash2, Download, Calendar as CalendarIcon, Filter } from "lucide-react";
import { formatCurrency, formatDate, exportToCSV } from "@/lib/utils";
import type { Expense, Category } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ExpenseDialog } from "@/components/expense-dialog";
import { CATEGORY_ICONS } from "@/lib/constants";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function Expenses() {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [expenseToDelete, setExpenseToDelete] = useState<string | null>(null);
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [dateFilter, setDateFilter] = useState<string>("all");
  const [sortBy, setSortBy] = useState<string>('date');

  const { data: expenses = [], isLoading } = useQuery<Expense[]>({
    queryKey: ['/api/expenses'],
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest('DELETE', `/api/expenses/${id}`),
    onMutate: async (id: string) => {
      await queryClient.cancelQueries({ queryKey: ['/api/expenses'] });
      const previous = queryClient.getQueryData<Expense[]>(['/api/expenses']) || [];
      queryClient.setQueryData(['/api/expenses'], previous.filter(e => e.id !== id));
      return { previous };
    },
    onError: (err, id, context: any) => {
      if (context?.previous) queryClient.setQueryData(['/api/expenses'], context.previous);
      toast({ title: 'Error', description: String(err) });
    },
    onSettled: () => queryClient.invalidateQueries({ queryKey: ['/api/expenses'] }),
    onSuccess: () => {
      toast({
        title: "Expense deleted",
        description: "The expense has been removed successfully.",
      });
      setDeleteDialogOpen(false);
      setExpenseToDelete(null);
    },
  });

  const handleEdit = (expense: Expense) => {
    setEditingExpense(expense);
    setDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    setExpenseToDelete(id);
    setDeleteDialogOpen(true);
  };

  const handleExport = () => {
    const exportData = filteredExpenses.map(expense => {
      const category = categories.find(c => c.id === expense.categoryId);
      return {
        Date: formatDate(expense.date),
        Description: expense.description,
        Category: category?.name || 'Unknown',
        Amount: parseFloat(expense.amount),
        Notes: expense.notes || '',
        Tags: expense.tags?.join(', ') || '',
      };
    });
    
    const today = new Date().toISOString().split('T')[0];
    exportToCSV(exportData, `finote-expenses-${today}.csv`);
    
    toast({
      title: "Export successful",
      description: `Exported ${exportData.length} expenses to CSV.`,
    });
  };

  const now = new Date();
  const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const thisYear = new Date(now.getFullYear(), 0, 1);

  let filteredExpenses = [...expenses];

  if (categoryFilter !== "all") {
    filteredExpenses = filteredExpenses.filter(e => e.categoryId === categoryFilter);
  }

  if (dateFilter === "today") {
    filteredExpenses = filteredExpenses.filter(e => {
      const date = new Date(e.date);
      return date.toDateString() === now.toDateString();
    });
  } else if (dateFilter === "week") {
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    filteredExpenses = filteredExpenses.filter(e => new Date(e.date) >= weekAgo);
  } else if (dateFilter === "month") {
    filteredExpenses = filteredExpenses.filter(e => new Date(e.date) >= thisMonth);
  } else if (dateFilter === "year") {
    filteredExpenses = filteredExpenses.filter(e => new Date(e.date) >= thisYear);
  }

  filteredExpenses.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  // Apply user-selected sorting
  if (sortBy === 'date') {
    filteredExpenses.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  } else if (sortBy === 'amount') {
    filteredExpenses.sort((a, b) => parseFloat(b.amount) - parseFloat(a.amount));
  } else if (sortBy === 'category') {
    // sort by category name; missing category goes last
    filteredExpenses.sort((a, b) => {
      const ca = categories.find(c => c.id === a.categoryId)?.name ?? '';
      const cb = categories.find(c => c.id === b.categoryId)?.name ?? '';
      return ca.localeCompare(cb);
    });
  }

  const totalAmount = filteredExpenses.reduce((sum, e) => sum + parseFloat(e.amount), 0);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground" data-testid="text-loading">Loading expenses...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6" data-testid="container-expenses">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground mb-2" data-testid="text-expenses-title">
            Expenses
          </h1>
          <p className="text-muted-foreground" data-testid="text-expenses-subtitle">
            Manage and track all your expenses
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={handleExport}
            disabled={filteredExpenses.length === 0}
            data-testid="button-export"
          >
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button onClick={() => { setEditingExpense(null); setDialogOpen(true); }} data-testid="button-add-expense">
            <Plus className="h-4 w-4 mr-2" />
            Add Expense
          </Button>
        </div>
      </div>

      <div className="flex gap-3 flex-wrap">
        <div className="flex items-center gap-2 flex-1 min-w-[200px]">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-full" data-testid="select-category-filter">
              <SelectValue placeholder="All categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All categories</SelectItem>
              {categories.map(cat => (
                <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center gap-2 flex-1 min-w-[200px]">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-full" data-testid="select-sort-by">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="date">Date</SelectItem>
              <SelectItem value="category">Category</SelectItem>
              <SelectItem value="amount">Amount</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center gap-2 flex-1 min-w-[200px]">
          <CalendarIcon className="h-4 w-4 text-muted-foreground" />
          <Select value={dateFilter} onValueChange={setDateFilter}>
            <SelectTrigger className="w-full" data-testid="select-date-filter">
              <SelectValue placeholder="All time" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All time</SelectItem>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="week">Last 7 days</SelectItem>
              <SelectItem value="month">This month</SelectItem>
              <SelectItem value="year">This year</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-heading font-semibold text-foreground">
            {filteredExpenses.length} expense{filteredExpenses.length !== 1 ? 's' : ''}
          </h2>
          <p className="text-xl font-bold font-heading tabular-nums text-destructive" data-testid="text-total-amount">
            {formatCurrency(totalAmount)}
          </p>
        </div>

        {filteredExpenses.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Plus className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2" data-testid="text-no-expenses">
              No expenses yet
            </h3>
            <p className="text-muted-foreground mb-4">
              Start tracking by adding your first expense
            </p>
            <Button onClick={() => { setEditingExpense(null); setDialogOpen(true); }} data-testid="button-add-first-expense">
              <Plus className="h-4 w-4 mr-2" />
              Add Expense
            </Button>
          </div>
        ) : (
          <div className="space-y-2">
            {filteredExpenses.map((expense) => {
              const category = categories.find(c => c.id === expense.categoryId);
              const IconComponent = category ? CATEGORY_ICONS[category.icon] : null;

              return (
                <div
                  key={expense.id}
                  className="flex items-center justify-between p-4 rounded-lg border border-border hover-elevate transition-all duration-200"
                  data-testid={`expense-item-${expense.id}`}
                >
                  <div className="flex items-center gap-4 flex-1 min-w-0">
                    {category && IconComponent && (
                      <div
                        className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: category.color + '20' }}
                      >
                        <IconComponent className="h-6 w-6" style={{ color: category.color }} />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-foreground truncate" data-testid={`text-expense-description-${expense.id}`}>
                          {expense.description}
                      </p>
                      {String(expense.id).startsWith('temp-') && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-amber-200 text-amber-800 ml-2">Queued</span>
                      )}
                      <div className="flex items-center gap-3 flex-wrap mt-1">
                        <p className="text-sm text-muted-foreground">
                          {formatDate(expense.date)}
                        </p>
                        {category && (
                          <span className="text-xs px-2 py-0.5 rounded-full" style={{ 
                            backgroundColor: category.color + '20',
                            color: category.color
                          }}>
                            {category.name}
                          </span>
                        )}
                        {expense.tags && expense.tags.length > 0 && (
                          <span className="text-xs text-muted-foreground">
                            {expense.tags.join(', ')}
                          </span>
                        )}
                      </div>
                      {expense.notes && (
                        <p className="text-sm text-muted-foreground mt-1 truncate">
                          {expense.notes}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 ml-4">
                    <p className="font-bold text-lg tabular-nums text-destructive whitespace-nowrap" data-testid={`text-expense-amount-${expense.id}`}>
                      {formatCurrency(parseFloat(expense.amount))}
                    </p>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEdit(expense)}
                        data-testid={`button-edit-${expense.id}`}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDelete(expense.id)}
                        data-testid={`button-delete-${expense.id}`}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>

      <ExpenseDialog
        open={dialogOpen}
        onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) setEditingExpense(null);
        }}
        expense={editingExpense}
        categories={categories}
      />

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete expense?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the expense.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => expenseToDelete && deleteMutation.mutate(expenseToDelete)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
