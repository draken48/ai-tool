import React, { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import ChatBox from '@/components/ChatBox';
import { useAuth } from '@/contexts/AuthContext';
import { apiRequest } from '@/lib/queryClient';

export default function AssistantPage(){
  const [messages, setMessages] = useState<Array<{role: string; content: string}>>([]);
  const [loading, setLoading] = useState(false);
  const qc = useQueryClient();
  const { token } = useAuth();

  const send = async (text: string) => {
    const newMsg = { role: 'user', content: text };
    setMessages((m) => [...m, newMsg]);
    setLoading(true);

    try {
      const data = await apiRequest('POST', '/api/assistant', { messages: [...messages, newMsg] }, token || null);
      setMessages((m) => [...m, { role: 'assistant', content: data.reply }]);
    } catch (e: any) {
      const msg = e?.message || String(e);
      setMessages((m) => [...m, { role: 'assistant', content: `Error: ${msg}` }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6 p-6">
      <h1 className="text-2xl font-heading font-bold">Finote Assistant</h1>

      <div className="space-y-4">
        {messages.map((m, i) => (
          <div key={i} className={`p-3 rounded-lg ${m.role === 'user' ? 'bg-primary/10' : 'bg-muted'}`}>
            <p className="whitespace-pre-wrap">{m.content}</p>
          </div>
        ))}
      </div>

      <ChatBox onSend={send} loading={loading} />
    </div>
  );
}
