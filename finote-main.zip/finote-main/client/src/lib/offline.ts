// Lightweight IndexedDB outbox queue for offline-first requests
// No external deps used to keep install minimal.

export interface OutboxEntry {
  id?: number;
  method: string;
  url: string;
  body?: any;
  headers?: Record<string, string>;
  createdAt: number;
  attempts: number;
}

const DB_NAME = 'finote_offline_db';
const STORE_NAME = 'outbox';
const DB_VERSION = 1;

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id', autoIncrement: true });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function enqueueOutgoingRequest(entry: Omit<OutboxEntry, 'id' | 'attempts' | 'createdAt'>) {
  const db = await openDB();
  return new Promise<number>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const item: OutboxEntry = {
      ...entry,
      createdAt: Date.now(),
      attempts: 0,
    };
    const req = store.add(item as any);
    req.onsuccess = () => resolve(req.result as number);
    req.onerror = () => reject(req.error);
  });
}

export async function getAllOutbox(): Promise<OutboxEntry[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result as OutboxEntry[]);
    req.onerror = () => reject(req.error);
  });
}

export async function getOutboxCount(): Promise<number> {
  const items = await getAllOutbox();
  return items.length;
}

export function isProcessorRunning(): boolean {
  return _processorRunning;
}

export async function removeOutboxEntry(id: number) {
  const db = await openDB();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

async function attemptSend(entry: OutboxEntry): Promise<boolean> {
  try {
    const res = await fetch(entry.url, {
      method: entry.method,
      headers: { ...(entry.headers || {}), 'Content-Type': 'application/json' },
      body: entry.body ? JSON.stringify(entry.body) : undefined,
      credentials: 'include',
    });

    if (res.ok) {
      return true;
    }
    // non-2xx, don't delete automatically; allow retry later
    return false;
  } catch (e) {
    return false;
  }
}

let _processorRunning = false;

export async function processOutboxOnce() {
  if (_processorRunning) return;
  _processorRunning = true;
  try {
    const items = await getAllOutbox();
    for (const item of items.sort((a,b) => a.createdAt - b.createdAt)) {
      const ok = await attemptSend(item);
      if (ok && item.id != null) {
        await removeOutboxEntry(item.id);
      } else {
        // bump attempts count for future logic (not implemented persistence update here for simplicity)
      }
    }
  } finally {
    _processorRunning = false;
  }
}

let _intervalHandle: number | null = null;

export function startOutboxProcessor(intervalMs = 15000) {
  if (_intervalHandle != null) return;
  // try immediately
  processOutboxOnce().catch(() => {});
  _intervalHandle = window.setInterval(() => {
    if (navigator.onLine) processOutboxOnce().catch(() => {});
  }, intervalMs) as unknown as number;
}

export function stopOutboxProcessor() {
  if (_intervalHandle != null) {
    clearInterval(_intervalHandle);
    _intervalHandle = null;
  }
}

export function initOffline() {
  // start processor when back online
  window.addEventListener('online', () => {
    startOutboxProcessor();
  });
  window.addEventListener('offline', () => {
    // no-op; UI will show offline state
  });
  if (navigator.onLine) startOutboxProcessor();
}
