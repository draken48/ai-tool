import { ShoppingBag, Coffee, Car, Film, Zap, Heart, GraduationCap, MoreHorizontal } from "lucide-react";

export const DEFAULT_CATEGORIES = [
  { name: 'Food', icon: 'Coffee', color: 'hsl(16, 90%, 58%)', isDefault: true },
  { name: 'Transport', icon: 'Car', color: 'hsl(200, 98%, 39%)', isDefault: true },
  { name: 'Entertainment', icon: 'Film', color: 'hsl(280, 87%, 65%)', isDefault: true },
  { name: 'Shopping', icon: 'ShoppingBag', color: 'hsl(340, 82%, 52%)', isDefault: true },
  { name: 'Bills', icon: 'Zap', color: 'hsl(38, 92%, 50%)', isDefault: true },
  { name: 'Health', icon: 'Heart', color: 'hsl(120, 61%, 50%)', isDefault: true },
  { name: 'Education', icon: 'GraduationCap', color: 'hsl(262, 52%, 47%)', isDefault: true },
  { name: 'Other', icon: 'MoreHorizontal', color: 'hsl(215, 20%, 65%)', isDefault: true },
];

export const CATEGORY_ICONS: Record<string, any> = {
  Coffee,
  Car,
  Film,
  ShoppingBag,
  Zap,
  Heart,
  GraduationCap,
  MoreHorizontal,
};

export const RECURRING_FREQUENCIES = [
  { value: 'daily', label: 'Daily' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'monthly', label: 'Monthly' },
  { value: 'yearly', label: 'Yearly' },
];

export const BUDGET_PERIODS = [
  { value: 'weekly', label: 'Weekly' },
  { value: 'monthly', label: 'Monthly' },
  { value: 'yearly', label: 'Yearly' },
];
