import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { insertExpenseSchema, type InsertExpense, type Expense, type Category } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { formatDateForInput, formatDate, formatCurrency } from "@/lib/utils";
import { CATEGORY_ICONS } from "@/lib/constants";
import { useState, useRef, useEffect } from "react";
import ReceiptUploader from "@/components/ReceiptUploader";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

interface ExpenseDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  expense: Expense | null;
  categories: Category[];
}

export function ExpenseDialog({ open, onOpenChange, expense, categories }: ExpenseDialogProps) {
  const { toast } = useToast();
  const { token } = useAuth();
  const [suggestedCategoryId, setSuggestedCategoryId] = useState<string | null>(null);
  const [suggesting, setSuggesting] = useState(false);
  const [mergeDialogOpen, setMergeDialogOpen] = useState(false);
  const [mergeCandidate, setMergeCandidate] = useState<Expense | null>(null);
  const [mergePayload, setMergePayload] = useState<InsertExpense | null>(null);
  
  const form = useForm<InsertExpense>({
    resolver: zodResolver(insertExpenseSchema),
    defaultValues: expense
      ? {
          amount: parseFloat(expense.amount),
          description: expense.description,
          categoryId: expense.categoryId,
          date: formatDateForInput(expense.date),
          notes: expense.notes || "",
          tags: expense.tags || [],
        }
      : {
          // leave amount undefined so validation requires the user to enter a positive value
          amount: undefined as unknown as number,
          description: "",
          // default to first category if available, otherwise undefined so the select shows placeholder
          categoryId: categories[0]?.id as any || undefined,
          date: formatDateForInput(new Date()),
          notes: "",
          tags: [],
        },
  });

  const createMutation = useMutation({
    mutationFn: (data: InsertExpense) => apiRequest('POST', '/api/expenses', data, token),
    // optimistic UI: add a temporary expense locally immediately
    onMutate: async (newExpense: InsertExpense) => {
      await queryClient.cancelQueries({ queryKey: ['/api/expenses'] });
      const previous = queryClient.getQueryData<Expense[]>(['/api/expenses']) || [];
      const tempId = `temp-${Date.now()}`;
      const temp: Expense = {
        id: tempId,
        userId: (newExpense as any).userId || '',
        amount: String(newExpense.amount),
        description: newExpense.description || '',
        categoryId: newExpense.categoryId || '',
        date: newExpense.date || new Date().toISOString(),
        notes: newExpense.notes || '',
        tags: (newExpense as any).tags || [],
        isRecurring: false,
        recurringId: null as any,
      } as Expense;
      queryClient.setQueryData(['/api/expenses'], [temp, ...previous]);
      return { previous };
    },
    onError: (err, newExpense, context: any) => {
      if (context?.previous) {
        queryClient.setQueryData(['/api/expenses'], context.previous);
      }
      toast({ title: 'Error', description: String(err) });
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
    },
    onSuccess: () => {
      toast({
        title: "Expense added",
        description: "Your expense has been saved successfully.",
      });
      onOpenChange(false);
      form.reset();
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data: InsertExpense) => apiRequest('PATCH', `/api/expenses/${expense?.id}`, data, token),
    onMutate: async (updated: InsertExpense) => {
      await queryClient.cancelQueries({ queryKey: ['/api/expenses'] });
      const previous = queryClient.getQueryData<Expense[]>(['/api/expenses']) || [];
      queryClient.setQueryData(['/api/expenses'], previous.map(e => e.id === expense?.id ? { ...e, ...updated, amount: String(updated.amount) } : e));
      return { previous };
    },
    onError: (err, updated, context: any) => {
      if (context?.previous) queryClient.setQueryData(['/api/expenses'], context.previous);
      toast({ title: 'Error', description: String(err) });
    },
    onSettled: () => queryClient.invalidateQueries({ queryKey: ['/api/expenses'] }),
    onSuccess: () => {
      toast({
        title: "Expense updated",
        description: "Your changes have been saved successfully.",
      });
      onOpenChange(false);
      form.reset();
    },
  });

  const onSubmit = async (data: InsertExpense) => {
    // tags may come as a string from the UI, an array, or be undefined/null.
    const rawTags = (data as any).tags;
    let tagsArray: string[] = [];
    if (typeof rawTags === 'string') {
      tagsArray = rawTags.split(',').map((t: string) => t.trim()).filter(Boolean);
    } else if (Array.isArray(rawTags)) {
      tagsArray = rawTags.filter(Boolean).map(String);
    }

    const submitData = { ...data, tags: tagsArray };

    if (expense) {
      updateMutation.mutate(submitData);
      return;
    }

    // client-side duplicate detection
    const allExpenses = queryClient.getQueryData<Expense[]>(['/api/expenses']) || [];
    const sameDay = (d1: string | Date, d2: string | Date) => {
      const a = new Date(d1);
      const b = new Date(d2);
      return a.toDateString() === b.toDateString();
    };
    const isSimilarDesc = (a?: string | null, b?: string | null) => {
      if (!a || !b) return false;
      const sa = a.toLowerCase();
      const sb = b.toLowerCase();
      return sa.includes(sb) || sb.includes(sa) || sa.split(' ')[0] === sb.split(' ')[0];
    };

    const possible = allExpenses.find(e => {
      const amountMatch = Math.abs(parseFloat(e.amount) - Number(data.amount)) < 0.01;
      const dateMatch = sameDay(e.date, data.date);
      const descMatch = isSimilarDesc(e.description, data.description);
      return amountMatch && dateMatch && descMatch;
    });

    if (possible) {
      const merged: InsertExpense = {
        description: data.description || possible.description,
        amount: Number(data.amount),
        date: data.date,
        categoryId: data.categoryId || possible.categoryId,
        notes: [possible.notes || '', data.notes || ''].filter(Boolean).join('\n'),
        tags: Array.from(new Set([...(possible.tags || []), ...((data as any).tags || [])])),
        currency: (data as any).currency || (possible as any).currency || 'INR',
      };
      setMergeCandidate(possible);
      setMergePayload(merged);
      setMergeDialogOpen(true);
      return;
    }

    createMutation.mutate(submitData);
  };

  const [showUploader, setShowUploader] = useState(false);
  const handleOCRResult = (res: { text: string; amount?: number; date?: string; merchant?: string }) => {
    // fill form fields heuristically
    if (res.amount) form.setValue('amount', res.amount as any);
    if (res.date) form.setValue('date', res.date as any);
    if (res.merchant) form.setValue('description', res.merchant as any);
    setShowUploader(false);
    toast({ title: 'Receipt parsed', description: 'We filled fields from the receipt. Please verify.' });
  };

  const getSuggestion = async (text: string) => {
    if (!text || text.trim().length < 3) return;
    if (categories.length === 0) return;
    setSuggesting(true);
    try {
      // prepare a short prompt listing category names and ask assistant to pick best match
      const catList = categories.map(c => `${c.id}:${c.name}`).join('\n');
      const prompt = `You are Finote assistant. Given the expense description: "${text}" pick the best matching category from the list below. Respond only with the category id if confident, otherwise respond with "none".\n\nCategories:\n${catList}`;
  const resp = await apiRequest('POST', '/api/assistant', { prompt }, token);
      const reply = resp?.reply?.trim();
      if (reply && reply !== 'none') {
        // try to extract an id from reply
        const idMatch = reply.match(/[a-zA-Z0-9\-_:]+/);
        const id = idMatch ? idMatch[0] : reply;
        const found = categories.find(c => c.id === id || c.name.toLowerCase() === reply.toLowerCase());
        if (found) setSuggestedCategoryId(found.id);
        else setSuggestedCategoryId(null);
      } else {
        setSuggestedCategoryId(null);
      }
    } catch (e) {
      setSuggestedCategoryId(null);
    } finally {
      setSuggesting(false);
    }
  };

  // simple debounce hook
  const debounceRef = useRef<number | null>(null);
  const debouncedSuggest = (val: string) => {
    if (debounceRef.current) window.clearTimeout(debounceRef.current);
    debounceRef.current = window.setTimeout(() => {
      getSuggestion(val).catch(() => {});
    }, 600) as unknown as number;
  };

  useEffect(() => () => { if (debounceRef.current) window.clearTimeout(debounceRef.current); }, []);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]" data-testid="dialog-expense">
        <DialogHeader>
          <DialogTitle className="text-2xl font-heading">
            {expense ? "Edit Expense" : "Add Expense"}
          </DialogTitle>
          <DialogDescription>
            {expense ? "Update the expense details below." : "Fill in the details of your expense."}
          </DialogDescription>
        </DialogHeader>

        {/* AlertDialog for merge confirmation */}
        <AlertDialog open={mergeDialogOpen} onOpenChange={setMergeDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Confirm Merge</AlertDialogTitle>
              <AlertDialogDescription>
                A possible duplicate was found:
                <br />
                {mergeCandidate?.description} — {mergeCandidate ? formatDate(mergeCandidate.date) : ''} — {mergeCandidate ? formatCurrency(parseFloat(String(mergeCandidate.amount))) : ''}
                <br />
                Merge your changes into this existing expense instead of creating a new one?
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel onClick={() => setMergeDialogOpen(false)}>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={async () => {
                      if (mergeCandidate && mergePayload) {
                    try {
                      await apiRequest('PATCH', `/api/expenses/${mergeCandidate.id}`, mergePayload, token);
                      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
                      toast({ title: 'Merged', description: 'Merged into existing expense.' });
                    } catch (e: any) {
                      toast({ title: 'Error', description: String(e?.message || e) });
                    }
                  }
                  setMergeDialogOpen(false);
                }}
              >
                Merge
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Amount (₹)</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="0.00"
                      {...field}
                      // allow empty input; only set a number when user types a numeric value
                      onChange={(e) => {
                        const v = e.target.value;
                        if (v === '' || v === undefined) field.onChange(undefined as any);
                        else field.onChange(parseFloat(v));
                      }}
                      data-testid="input-amount"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="e.g., Grocery shopping"
                      {...field}
                      data-testid="input-description"
                      onChange={(e) => {
                        field.onChange(e.target.value);
                        debouncedSuggest(e.target.value);
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="categoryId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value ?? undefined}>
                    <FormControl>
                      <SelectTrigger data-testid="select-category">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {categories.map((cat) => {
                        const IconComponent = CATEGORY_ICONS[cat.icon];
                        return (
                          <SelectItem key={cat.id} value={cat.id}>
                            <div className="flex items-center gap-2">
                              {IconComponent && <IconComponent className="h-4 w-4" style={{ color: cat.color }} />}
                              <span>{cat.name}</span>
                            </div>
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                  {suggestedCategoryId && (
                    <div className="mt-2 flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">Suggested:</span>
                      <Button size="sm" variant="outline" onClick={() => field.onChange(suggestedCategoryId)} data-testid="button-apply-suggestion">
                        Apply suggestion
                      </Button>
                      {suggesting && <span className="text-xs text-muted-foreground">Thinking...</span>}
                    </div>
                  )}
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Date</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} data-testid="input-date" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes (optional)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Additional details..."
                      className="resize-none"
                      rows={3}
                      {...field}
                      // ensure value is a string for the textarea element
                      value={field.value ?? ''}
                      data-testid="input-notes"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex items-center gap-2">
              <Button type="button" variant="ghost" onClick={() => setShowUploader(s => !s)} data-testid="button-upload-receipt">Upload receipt</Button>
              <span className="text-sm text-muted-foreground">or paste details manually</span>
            </div>

            {showUploader && (
              <div className="p-2 border rounded-md">
                <ReceiptUploader onResult={handleOCRResult} onClose={() => setShowUploader(false)} />
              </div>
            )}

            <FormField
              control={form.control}
              name="tags"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tags (optional)</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="work, personal, urgent (comma separated)"
                      {...field}
                      // render array tags as comma-separated string when present
                      value={Array.isArray(field.value) ? field.value.join(', ') : (field.value ?? '')}
                      data-testid="input-tags"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                className="flex-1"
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createMutation.isPending || updateMutation.isPending}
                className="flex-1"
                data-testid="button-submit"
              >
                {createMutation.isPending || updateMutation.isPending ? "Saving..." : expense ? "Update" : "Add"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
