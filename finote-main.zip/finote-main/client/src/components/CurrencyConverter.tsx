import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { CurrencySelector } from './CurrencySelector';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { ArrowUpDown, Loader2 } from 'lucide-react';

interface ConversionResult {
  originalAmount: number;
  originalCurrency: string;
  convertedAmount: number;
  convertedCurrency: string;
  rate: number;
}

export function CurrencyConverter() {
  const [amount, setAmount] = useState('100');
  const [fromCurrency, setFromCurrency] = useState('INR');
  const [toCurrency, setToCurrency] = useState('USD');
  const [conversionResult, setConversionResult] = useState<ConversionResult | null>(null);
  const [isConverting, setIsConverting] = useState(false);

  interface CurrencyInfo { code: string; symbol?: string }
  const { data: currencies = [] as CurrencyInfo[] } = useQuery({
    queryKey: ['/api/currencies'],
  });

  const convertCurrency = async () => {
    if (!amount || !fromCurrency || !toCurrency) return;

    setIsConverting(true);
    try {
      const result = await apiRequest('GET', `/api/currencies/convert?amount=${amount}&from=${fromCurrency}&to=${toCurrency}`);
      setConversionResult(result);
    } catch (error) {
      console.error('Conversion failed:', error);
    } finally {
      setIsConverting(false);
    }
  };

  const swapCurrencies = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
  };

  useEffect(() => {
    if (amount && fromCurrency && toCurrency) {
      const timeoutId = setTimeout(() => {
        convertCurrency();
      }, 500);
      return () => clearTimeout(timeoutId);
    }
  }, [amount, fromCurrency, toCurrency]);

  const formatAmount = (amount: number, currency: string) => {
    const currencyInfo = Array.isArray(currencies) ? currencies.find((c) => c.code === currency) : undefined;
    if (!currencyInfo) return `${currency} ${amount.toFixed(2)}`;

    switch (currency) {
      case 'INR':
        return `₹${amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      case 'USD':
        return `$${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      case 'EUR':
        return `€${amount.toLocaleString('en-EU', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      case 'GBP':
        return `£${amount.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      case 'JPY':
        return `¥${amount.toLocaleString('ja-JP', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
      default:
        return `${currencyInfo.symbol ?? currency} ${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Currency Converter</CardTitle>
        <CardDescription>
          Convert between different currencies using real-time exchange rates
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="amount">Amount</Label>
          <Input
            id="amount"
            type="number"
            placeholder="Enter amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>From</Label>
            <CurrencySelector
              value={fromCurrency}
              onValueChange={setFromCurrency}
              placeholder="Select currency"
            />
          </div>

          <div className="flex items-end">
            <Button
              variant="outline"
              size="icon"
              onClick={swapCurrencies}
              className="w-full"
            >
              <ArrowUpDown className="h-4 w-4" />
            </Button>
          </div>

          <div className="space-y-2">
            <Label>To</Label>
            <CurrencySelector
              value={toCurrency}
              onValueChange={setToCurrency}
              placeholder="Select currency"
            />
          </div>
        </div>

        {conversionResult && (
          <div className="p-4 bg-muted rounded-lg">
            <div className="text-center space-y-2">
              <div className="text-2xl font-bold">
                {formatAmount(conversionResult.convertedAmount, conversionResult.convertedCurrency)}
              </div>
              <div className="text-sm text-muted-foreground">
                1 {conversionResult.originalCurrency} = {conversionResult.rate.toFixed(4)} {conversionResult.convertedCurrency}
              </div>
              <div className="text-xs text-muted-foreground">
                {formatAmount(conversionResult.originalAmount, conversionResult.originalCurrency)} = {formatAmount(conversionResult.convertedAmount, conversionResult.convertedCurrency)}
              </div>
            </div>
          </div>
        )}

        {isConverting && (
          <div className="flex items-center justify-center py-4">
            <Loader2 className="h-4 w-4 animate-spin" />
            <span className="ml-2 text-sm text-muted-foreground">Converting...</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
