import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { insertRecurringPaymentSchema, type InsertRecurringPayment, type RecurringPayment, type Category } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { RECURRING_FREQUENCIES, CATEGORY_ICONS } from "@/lib/constants";
import { formatDateForInput } from "@/lib/utils";

interface RecurringDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  payment: RecurringPayment | null;
  categories: Category[];
}

export function RecurringDialog({ open, onOpenChange, payment, categories }: RecurringDialogProps) {
  const { toast } = useToast();
  
  const form = useForm<InsertRecurringPayment>({
    resolver: zodResolver(insertRecurringPaymentSchema),
    defaultValues: payment ? {
      amount: parseFloat(payment.amount),
      description: payment.description,
      categoryId: payment.categoryId,
      frequency: payment.frequency,
      startDate: formatDateForInput(payment.startDate),
      nextDue: formatDateForInput(payment.nextDue),
      isActive: payment.isActive,
      notes: payment.notes || "",
    } : {
      amount: 0,
      description: "",
      categoryId: categories[0]?.id || "",
      frequency: "monthly",
      startDate: formatDateForInput(new Date()),
      nextDue: formatDateForInput(new Date()),
      isActive: true,
      notes: "",
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: InsertRecurringPayment) => apiRequest('POST', '/api/recurring-payments', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/recurring-payments'] });
      toast({
        title: "Recurring payment added",
        description: "Your recurring payment has been saved successfully.",
      });
      onOpenChange(false);
      form.reset();
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data: InsertRecurringPayment) => apiRequest('PATCH', `/api/recurring-payments/${payment?.id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/recurring-payments'] });
      toast({
        title: "Recurring payment updated",
        description: "Your changes have been saved successfully.",
      });
      onOpenChange(false);
      form.reset();
    },
  });

  const onSubmit = (data: InsertRecurringPayment) => {
    if (payment) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]" data-testid="dialog-recurring">
        <DialogHeader>
          <DialogTitle className="text-2xl font-heading">
            {payment ? "Edit Recurring Payment" : "Add Recurring Payment"}
          </DialogTitle>
          <DialogDescription>
            {payment ? "Update the recurring payment details." : "Set up a subscription or regular expense."}
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Amount (₹)</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="0.00"
                      {...field}
                      onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                      data-testid="input-amount"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Netflix subscription" {...field} data-testid="input-description" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="categoryId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value ?? undefined}>
                    <FormControl>
                      <SelectTrigger data-testid="select-category">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {categories.map((cat) => {
                        const IconComponent = CATEGORY_ICONS[cat.icon];
                        return (
                          <SelectItem key={cat.id} value={cat.id}>
                            <div className="flex items-center gap-2">
                              {IconComponent && <IconComponent className="h-4 w-4" style={{ color: cat.color }} />}
                              <span>{cat.name}</span>
                            </div>
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="frequency"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Frequency</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value ?? undefined}>
                    <FormControl>
                      <SelectTrigger data-testid="select-frequency">
                        <SelectValue placeholder="Select frequency" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {RECURRING_FREQUENCIES.map((freq) => (
                        <SelectItem key={freq.value} value={freq.value}>
                          {freq.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Start Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} data-testid="input-start-date" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="nextDue"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Next Due</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} data-testid="input-next-due" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes (optional)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Additional details..."
                      className="resize-none"
                      rows={3}
                      {...field}
                      value={field.value ?? ''}
                      data-testid="input-notes"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                className="flex-1"
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createMutation.isPending || updateMutation.isPending}
                className="flex-1"
                data-testid="button-submit"
              >
                {createMutation.isPending || updateMutation.isPending ? "Saving..." : payment ? "Update" : "Add"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
