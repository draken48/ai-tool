import { useState } from 'react';

type OCRResult = {
  text: string;
  amount?: number;
  date?: string;
  merchant?: string;
};

export default function ReceiptUploader({ onResult, onClose }:{ onResult: (r: OCRResult) => void, onClose?: () => void }){
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFile = async (file: File | null) => {
    if (!file) return;
    setError(null);
    setLoading(true);
    try {
      // Try dynamic import of tesseract.js
      let Tesseract: any = null;
      try {
        // dynamic import; tesseract may not be installed in this environment
        // @ts-ignore
        Tesseract = await import('tesseract.js');
      } catch (e) {
        setError('tesseract.js not installed. Run `npm install tesseract.js` to enable OCR.');
        setLoading(false);
        return;
      }

      const { createWorker } = Tesseract;
      const worker = createWorker({ logger: () => {} });
      await worker.load();
      await worker.loadLanguage('eng');
      await worker.initialize('eng');
      const { data: { text } } = await worker.recognize(file);
      await worker.terminate();

      // simple extraction heuristics
      const amountMatch = text.match(/₹?\s*([0-9]{1,3}(?:[,0-9]*)(?:\.[0-9]{1,2})?)/i);
      const dateMatch = text.match(/(\d{4}[-\/.]\d{1,2}[-\/.]\d{1,2})|(\d{1,2}[-\/.]\d{1,2}[-\/.]\d{2,4})/);
  const merchantMatch = text.split('\n').find((line: string) => line.trim().length > 2);

      const result: OCRResult = { text };
      if (amountMatch) {
        const num = amountMatch[1].replace(/,/g, '');
        result.amount = parseFloat(num);
      }
      if (dateMatch) result.date = (dateMatch[0]);
      if (merchantMatch) result.merchant = merchantMatch.trim();

      onResult(result);
    } catch (e: any) {
      setError(String(e?.message || e));
    } finally {
      setLoading(false);
      if (onClose) onClose();
    }
  };

  return (
    <div className="space-y-2">
      <input
        type="file"
        accept="image/*"
        onChange={(e) => handleFile(e.target.files?.[0] ?? null)}
        data-testid="input-receipt-file"
      />
      {loading && <div className="text-sm text-muted-foreground">Running OCR...</div>}
      {error && <div className="text-sm text-destructive">{error}</div>}
      <div className="text-xs text-muted-foreground">Tip: For better results use clear photos of receipts.</div>
    </div>
  );
}
