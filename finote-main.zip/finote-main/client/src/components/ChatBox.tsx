import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export default function ChatBox({ onSend, loading }:{ onSend: (msg: string) => Promise<void>, loading?: boolean }){
  const [text, setText] = useState('');

  const submit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!text.trim()) return;
    await onSend(text.trim());
    setText('');
  }

  return (
    <div className="w-full max-w-2xl mx-auto">
      <form onSubmit={submit} className="flex gap-2">
        <Input value={text} onChange={(e) => setText(e.target.value)} placeholder="Ask Finote..." />
        <Button type="submit" disabled={loading}>{loading ? 'Sending...' : 'Send'}</Button>
      </form>
    </div>
  );
}
