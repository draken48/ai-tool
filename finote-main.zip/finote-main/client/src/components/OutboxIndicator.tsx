import { useEffect, useState } from 'react';
import { getOutboxCount, isProcessorRunning } from '@/lib/offline';

export default function OutboxIndicator(){
  const [count, setCount] = useState<number>(0);
  const [running, setRunning] = useState<boolean>(false);

  useEffect(() => {
    let mounted = true;
    const refresh = async () => {
      try {
        const c = await getOutboxCount();
        if (!mounted) return;
        setCount(c);
        setRunning(isProcessorRunning());
      } catch (e) {
        // ignore
      }
    };
    refresh();
    const id = window.setInterval(refresh, 5000);
    return () => { mounted = false; clearInterval(id); };
  }, []);

  if (count === 0) return null;
  return (
    <div className="flex items-center gap-2">
      {running ? (
        <div className="w-4 h-4 border-2 border-primary rounded-full animate-spin" aria-hidden />
      ) : (
        <div className="w-3 h-3 rounded-full bg-amber-500" aria-hidden />
      )}
      <span className="text-sm text-muted-foreground">{count} queued</span>
    </div>
  );
}
