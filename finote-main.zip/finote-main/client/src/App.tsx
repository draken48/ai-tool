import { Switch, Route, useLocation } from "wouter";
import { useState, useEffect } from "react";
import { queryClient, apiRequest } from "./lib/queryClient";
import { QueryClientProvider, useQuery, useMutation } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import OfflineIndicator from "@/components/OfflineIndicator";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { LayoutDashboard, Wallet, Calendar, Settings as SettingsIcon, Plus, Moon, Sun, LogOut } from "lucide-react";
import { useTheme } from "@/components/theme-provider";
import { DEFAULT_CATEGORIES } from "@/lib/constants";
import type { Category } from "@shared/schema";
import { AuthPage } from "@/components/auth/AuthPage";
import { NotificationCenter } from "@/components/NotificationCenter";

import Dashboard from "@/pages/dashboard";
import Expenses from "@/pages/expenses";
import Budgets from "@/pages/budgets";
import Recurring from "@/pages/recurring";
import Categories from "@/pages/categories";
import Settings from "@/pages/settings";
import NotFound from "@/pages/not-found";
import { ExpenseDialog } from "@/components/expense-dialog";
import { useToast } from "@/hooks/use-toast";
import Assistant from "@/pages/assistant";
import { initOffline } from "@/lib/offline";
import OutboxIndicator from "@/components/OutboxIndicator";

function Navigation() {
  const [location, setLocation] = useLocation();
  const { theme, toggleTheme } = useTheme();
  const { user, logout } = useAuth();

  const navItems = [
    { path: "/", icon: LayoutDashboard, label: "Dashboard" },
    { path: "/expenses", icon: Wallet, label: "Expenses" },
      { path: "/categories", icon: LayoutDashboard, label: "Categories" },
    { path: "/budgets", icon: LayoutDashboard, label: "Budgets" },
    { path: "/recurring", icon: Calendar, label: "Recurring" },
    { path: "/assistant", icon: LayoutDashboard, label: "Assistant" },
    { path: "/settings", icon: SettingsIcon, label: "Settings" },
  ];

  return (
    <>
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-chart-2 flex items-center justify-center">
                <Wallet className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-xl font-heading font-bold text-foreground">Finote</h1>
            </div>

            <div className="hidden md:flex items-center gap-1">
              {navItems.map((item) => (
                <Button
                  key={item.path}
                  variant={location === item.path ? "secondary" : "ghost"}
                  onClick={() => setLocation(item.path)}
                  className={cn(
                    "gap-2",
                    location === item.path && "bg-secondary"
                  )}
                  data-testid={`nav-${item.label.toLowerCase()}`}
                >
                  <item.icon className="h-4 w-4" />
                  <span className="hidden lg:inline">{item.label}</span>
                </Button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <span className="hidden md:inline text-sm text-muted-foreground">
                {user?.name}
              </span>
              <div className="hidden md:flex">
                <OutboxIndicator />
              </div>
              <NotificationCenter />
              <Button
                variant="ghost"
                size="icon"
                onClick={logout}
                title="Logout"
              >
                <LogOut className="h-5 w-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                data-testid="button-theme-toggle"
              >
                {theme === 'dark' ? (
                  <Sun className="h-5 w-5" />
                ) : (
                  <Moon className="h-5 w-5" />
                )}
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-t border-border">
        <div className="flex items-center justify-around px-2 py-2">
          {navItems.map((item) => (
            <Button
              key={item.path}
              variant="ghost"
              size="sm"
              onClick={() => setLocation(item.path)}
              className={cn(
                "flex-col h-auto py-2 px-3 gap-1",
                location === item.path && "text-primary"
              )}
              data-testid={`nav-mobile-${item.label.toLowerCase()}`}
            >
              <item.icon className="h-5 w-5" />
              <span className="text-xs">{item.label}</span>
            </Button>
          ))}
        </div>
      </div>
    </>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/expenses" component={Expenses} />
      <Route path="/categories" component={Categories} />
      <Route path="/budgets" component={Budgets} />
      <Route path="/recurring" component={Recurring} />
      <Route path="/assistant" component={Assistant} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function FloatingActionButton() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const { token } = useAuth();
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
    enabled: !!token,
  });

  return (
    <>
      <Button
        size="icon"
        className="fixed bottom-20 md:bottom-8 right-4 md:right-8 h-14 w-14 rounded-full shadow-lg hover:shadow-xl transition-all duration-200 z-40"
        onClick={() => setDialogOpen(true)}
        data-testid="button-fab"
      >
        <Plus className="h-6 w-6" />
      </Button>

      <ExpenseDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        expense={null}
        categories={categories}
      />
    </>
  );
}

function InitializeData() {
  const { toast } = useToast();
  const { token } = useAuth();
  
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
    enabled: !!token,
  });

  const createCategoryMutation = useMutation({
    mutationFn: (category: any) => apiRequest('POST', '/api/categories', category, token),
  });

  useEffect(() => {
    if (categories.length === 0 && token) {
      DEFAULT_CATEGORIES.forEach(cat => {
        createCategoryMutation.mutate(cat);
      });
    }
  }, [categories.length, token]);

  return null;
}

function ProtectedApp() {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return <AuthPage />;
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <InitializeData />
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-6">
        <Router />
      </main>
      <FloatingActionButton />
      <Toaster />
    </div>
  );
}

function App() {
  useEffect(() => {
    // initialize offline queue processing
    try { initOffline(); } catch (e) { /* ignore init failures in non-browser env */ }
  }, []);
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <AuthProvider>
            <OfflineIndicator />
            <ProtectedApp />
          </AuthProvider>
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
