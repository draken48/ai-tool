# Finote PWA Design Guidelines

## Design Approach

**Hybrid Modern Fintech System** - Drawing from Material Design principles with inspiration from successful expense tracking apps (Splitwise, YNAB, Wallet) to create a trustworthy yet engaging financial management experience. Focus on clarity, data hierarchy, and encouraging daily engagement through delightful micro-interactions.

## Core Design Principles

1. **Trust & Clarity**: Financial apps must inspire confidence through clean layouts and clear data visualization
2. **Scannable Hierarchy**: Users should instantly understand their financial status at a glance
3. **Encouraging Engagement**: Make expense entry effortless and rewarding through smooth interactions
4. **Data-First Design**: Charts and numbers are heroes, not afterthoughts

## Color Palette

### Light Mode
- **Primary Brand**: 142 71% 45% (Trustworthy teal-green, financial growth)
- **Primary Hover**: 142 71% 38%
- **Secondary**: 262 52% 47% (Deep purple for accents)
- **Background**: 0 0% 98%
- **Surface**: 0 0% 100%
- **Text Primary**: 222 47% 11%
- **Text Secondary**: 215 16% 47%
- **Border**: 214 32% 91%

### Dark Mode
- **Primary Brand**: 142 71% 55%
- **Primary Hover**: 142 71% 62%
- **Secondary**: 262 52% 57%
- **Background**: 222 47% 11%
- **Surface**: 217 33% 17%
- **Text Primary**: 0 0% 98%
- **Text Secondary**: 215 20% 65%
- **Border**: 217 33% 24%

### Semantic Colors (Both Modes)
- **Success/Income**: 142 76% 36% (light) / 142 71% 45% (dark)
- **Danger/Expense**: 0 84% 60% (light) / 0 72% 51% (dark)
- **Warning/Budget Alert**: 38 92% 50% (light) / 45 93% 58% (dark)
- **Info**: 217 91% 60% (light) / 217 91% 70% (dark)

### Category Color System
Each expense category gets a distinct color for instant recognition in charts and lists. Use vibrant, differentiated hues: Food (16 90% 58%), Transport (200 98% 39%), Entertainment (280 87% 65%), Shopping (340 82% 52%), Bills (38 92% 50%), Health (120 61% 50%), Education (262 52% 47%), Other (215 20% 65%)

## Typography

**Font Families**: 
- Primary: 'Inter' for UI, numbers, and data (excellent readability for financial figures)
- Headings: 'Plus Jakarta Sans' for warmth and modern appeal

**Scale**:
- Hero Numbers (Budget totals): text-5xl/text-6xl, font-bold
- Page Headings: text-2xl/text-3xl, font-semibold
- Section Titles: text-lg, font-semibold
- Body: text-base, font-normal
- Labels/Captions: text-sm, font-medium
- Tiny Details: text-xs

**Currency Display**: Always prefix amounts with ₹ symbol, use tabular-nums for alignment, format large numbers with Indian numbering system (₹1,00,000 not ₹100,000)

## Layout System

**Spacing Primitives**: Use Tailwind units of 1, 2, 3, 4, 6, 8, 12, 16, 20 for consistent rhythm.

**Container Strategy**:
- Mobile-first responsive design
- Max container width: max-w-7xl
- Standard page padding: px-4 (mobile), px-6 (tablet), px-8 (desktop)
- Section spacing: space-y-6 (mobile), space-y-8 (desktop)

**Grid Patterns**:
- Expense list: Single column on mobile, grid with 1-2 items on desktop
- Category cards: 2 columns on mobile, 3-4 on tablet/desktop
- Dashboard stats: 2x2 grid on mobile, 4 columns on desktop

## Component Library

### Dashboard Cards
- Elevated cards with subtle shadow (shadow-sm hover:shadow-md)
- Rounded corners: rounded-xl
- Padding: p-6
- Background with subtle border
- Smooth transitions on hover

### Expense Item Cards
- Compact horizontal layout
- Category color indicator (4px left border or colored icon background)
- Amount right-aligned with expense in red, income in green
- Secondary info (date, notes) in smaller, muted text
- Swipe gestures on mobile for quick actions (edit/delete)

### Charts & Visualizations
- Use Chart.js or Recharts for responsive charts
- Pie charts for category breakdown
- Bar charts for monthly comparisons
- Line charts for spending trends
- Maintain category color consistency across all charts
- Light grid lines, prominent data points

### Forms & Input
- Floating labels for all inputs
- Currency input with large, tap-friendly number pad
- Category selector as horizontal scrolling chips or grid picker
- Date picker with calendar interface
- Notes field as expanding textarea
- Clear visual feedback on input focus (ring-2 ring-primary)

### Navigation
- Bottom navigation bar on mobile (4-5 primary actions)
- Sidebar on tablet/desktop
- Floating Action Button (FAB) for quick expense entry - prominently placed, uses primary color
- Icons from Heroicons (outline for inactive, solid for active states)

### Buttons
- Primary: Solid background with primary color, white text
- Secondary: Outline style with primary border
- Danger: Red background for delete actions
- Size variants: Default (py-2.5 px-4), Small (py-1.5 px-3), Large (py-3 px-6)
- Rounded: rounded-lg
- Hover states with brightness adjustment

### Budget Progress Bars
- Horizontal bars showing spent vs. budget
- Color transitions: green (under budget) → yellow (approaching) → red (over budget)
- Percentage indicator
- Height: h-2 (small indicators), h-4 (prominent displays)

### Alerts & Notifications
- Toast notifications for confirmations/errors (top-right on desktop, bottom on mobile)
- Budget warning banners with dismissible option
- Color-coded by severity
- Include icon + message + optional action

## Animations

**Use Sparingly** - Only where they enhance usability:
- Page transitions: Subtle fade (duration-200)
- Card entry: Gentle slide-up on mount
- Number changes: Smooth counting animation for budget updates
- FAB pulse: Subtle scale on first visit to encourage interaction
- Chart reveals: Stagger bar/line animations on load
- NO gratuitous hover animations or parallax effects

## Mobile-Specific Considerations

- Touch targets minimum 44x44px
- Adequate spacing between interactive elements
- Bottom sheet modals for forms on mobile (easier thumb reach)
- Swipe gestures for common actions
- Pull-to-refresh on expense list
- Optimized keyboard for number entry (numeric keypad)

## Images

**Minimal Image Usage** - This is a data-focused utility app:
- **NO hero image required** - Dashboard leads with financial summary
- Empty state illustrations: Simple, friendly SVG illustrations when no expenses exist (e.g., "Start tracking your first expense")
- Onboarding screens: 3-4 simple illustrations explaining key features
- Category icons: Consistent icon set (Heroicons) in category colors, not photos

## PWA-Specific Design

- App icon: Simple, recognizable logo mark in primary brand color on white/dark background
- Splash screen: Centered logo with app name, brand color background
- Install prompt: Non-intrusive banner at appropriate time (after 2-3 interactions)
- Offline indicator: Subtle banner when connection lost
- Update prompt: Toast notification when new version available

## Dark Mode Implementation

Maintain full dark mode support with:
- True dark backgrounds (not just gray)
- Reduced contrast to prevent eye strain
- Elevated surfaces slightly lighter than background
- Border visibility through subtle lightness differences
- All form inputs with dark backgrounds and light text
- Charts with adjusted colors for dark theme visibility