import { sql } from "drizzle-orm";
import { pgTable, text, varchar, numeric, timestamp, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email", { length: 255 }).notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  avatar: text("avatar"),
  defaultCurrency: varchar("default_currency", { length: 3 }).notNull().default("INR"),
  createdAt: timestamp("created_at", { mode: "string" }).notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at", { mode: "string" }).notNull().default(sql`now()`),
});

export const sessions = pgTable("sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  token: text("token").notNull().unique(),
  expiresAt: timestamp("expires_at", { mode: "string" }).notNull(),
  createdAt: timestamp("created_at", { mode: "string" }).notNull().default(sql`now()`),
});

export const categories = pgTable("categories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  name: text("name").notNull(),
  icon: text("icon").notNull(),
  color: text("color").notNull(),
  parentId: varchar("parent_id"),
  isDefault: boolean("is_default").notNull().default(false),
});

export const expenses = pgTable("expenses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 3 }).notNull().default("INR"),
  description: text("description").notNull(),
  categoryId: varchar("category_id").notNull(),
  date: timestamp("date", { mode: "string" }).notNull(),
  notes: text("notes"),
  tags: text("tags").array(),
  isRecurring: boolean("is_recurring").notNull().default(false),
  recurringId: varchar("recurring_id"),
  createdAt: timestamp("created_at", { mode: "string" }).notNull().default(sql`now()`),
});

export const budgets = pgTable("budgets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  categoryId: varchar("category_id"),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 3 }).notNull().default("INR"),
  period: text("period").notNull(),
  startDate: timestamp("start_date", { mode: "string" }).notNull(),
  endDate: timestamp("end_date", { mode: "string" }).notNull(),
  alertThreshold: integer("alert_threshold").notNull().default(80),
  isTotal: boolean("is_total").notNull().default(false),
});

export const recurringPayments = pgTable("recurring_payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 3 }).notNull().default("INR"),
  description: text("description").notNull(),
  categoryId: varchar("category_id").notNull(),
  frequency: text("frequency").notNull(),
  startDate: timestamp("start_date", { mode: "string" }).notNull(),
  nextDue: timestamp("next_due", { mode: "string" }).notNull(),
  isActive: boolean("is_active").notNull().default(true),
  notes: text("notes"),
});

export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  type: text("type").notNull(), // 'budget_alert', 'recurring_due', 'system'
  title: text("title").notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").notNull().default(false),
  data: text("data"), // JSON string for additional data
  createdAt: timestamp("created_at", { mode: "string" }).notNull().default(sql`now()`),
});

export const currencyRates = pgTable("currency_rates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fromCurrency: varchar("from_currency", { length: 3 }).notNull(),
  toCurrency: varchar("to_currency", { length: 3 }).notNull(),
  rate: numeric("rate", { precision: 10, scale: 6 }).notNull(),
  lastUpdated: timestamp("last_updated", { mode: "string" }).notNull().default(sql`now()`),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  password: z.string().min(6),
  email: z.string().email(),
  defaultCurrency: z.string().length(3).default("INR"),
});

export const insertSessionSchema = createInsertSchema(sessions).omit({
  id: true,
  createdAt: true,
});

export const insertCategorySchema = createInsertSchema(categories).omit({
  id: true,
  isDefault: true,
  userId: true,
});

export const insertExpenseSchema = createInsertSchema(expenses).omit({
  id: true,
  createdAt: true,
  isRecurring: true,
  recurringId: true,
  userId: true,
}).extend({
  amount: z.coerce.number().positive(),
  currency: z.string().length(3).default("INR"),
  tags: z.array(z.string()).optional(),
});

export const insertBudgetSchema = createInsertSchema(budgets).omit({
  id: true,
  userId: true,
}).extend({
  amount: z.coerce.number().positive(),
  currency: z.string().length(3).default("INR"),
  alertThreshold: z.coerce.number().min(1).max(100),
});

export const insertRecurringPaymentSchema = createInsertSchema(recurringPayments).omit({
  id: true,
  userId: true,
}).extend({
  amount: z.coerce.number().positive(),
  currency: z.string().length(3).default("INR"),
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  userId: true,
  createdAt: true,
}).extend({
  data: z.string().optional(),
});

export const insertCurrencyRateSchema = createInsertSchema(currencyRates).omit({
  id: true,
  lastUpdated: true,
}).extend({
  rate: z.coerce.number().positive(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessions.$inferSelect;

export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categories.$inferSelect;

export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type Expense = typeof expenses.$inferSelect;

export type InsertBudget = z.infer<typeof insertBudgetSchema>;
export type Budget = typeof budgets.$inferSelect;

export type InsertRecurringPayment = z.infer<typeof insertRecurringPaymentSchema>;
export type RecurringPayment = typeof recurringPayments.$inferSelect;

export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;

export type InsertCurrencyRate = z.infer<typeof insertCurrencyRateSchema>;
export type CurrencyRate = typeof currencyRates.$inferSelect;
