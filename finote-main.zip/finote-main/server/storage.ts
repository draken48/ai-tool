import { 
  type User, type InsertUser,
  type Session, type InsertSession,
  type Category, type InsertCategory,
  type Expense, type InsertExpense,
  type Budget, type InsertBudget,
  type RecurringPayment, type InsertRecurringPayment,
  type Notification, type InsertNotification
} from "@shared/schema";
import { randomUUID } from "crypto";
import bcrypt from "bcryptjs";

export interface IStorage {
  // User management
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserById(id: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: string): Promise<boolean>;

  // Session management
  createSession(session: InsertSession): Promise<Session>;
  getSessionByToken(token: string): Promise<Session | undefined>;
  deleteSession(token: string): Promise<boolean>;
  deleteUserSessions(userId: string): Promise<boolean>;

  // Category management (user-scoped)
  getCategories(userId: string): Promise<Category[]>;
  getCategory(id: string, userId: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory, userId: string): Promise<Category>;
  updateCategory(id: string, category: Partial<InsertCategory>, userId: string): Promise<Category | undefined>;
  deleteCategory(id: string, userId: string): Promise<boolean>;

  // Expense management (user-scoped)
  getExpenses(userId: string): Promise<Expense[]>;
  getExpense(id: string, userId: string): Promise<Expense | undefined>;
  createExpense(expense: InsertExpense, userId: string): Promise<Expense>;
  updateExpense(id: string, expense: Partial<InsertExpense>, userId: string): Promise<Expense | undefined>;
  deleteExpense(id: string, userId: string): Promise<boolean>;

  // Budget management (user-scoped)
  getBudgets(userId: string): Promise<Budget[]>;
  getBudget(id: string, userId: string): Promise<Budget | undefined>;
  createBudget(budget: InsertBudget, userId: string): Promise<Budget>;
  updateBudget(id: string, budget: Partial<InsertBudget>, userId: string): Promise<Budget | undefined>;
  deleteBudget(id: string, userId: string): Promise<boolean>;

  // Recurring payment management (user-scoped)
  getRecurringPayments(userId: string): Promise<RecurringPayment[]>;
  getRecurringPayment(id: string, userId: string): Promise<RecurringPayment | undefined>;
  createRecurringPayment(payment: InsertRecurringPayment, userId: string): Promise<RecurringPayment>;
  updateRecurringPayment(id: string, payment: Partial<InsertRecurringPayment>, userId: string): Promise<RecurringPayment | undefined>;
  deleteRecurringPayment(id: string, userId: string): Promise<boolean>;

  // Notification management (user-scoped)
  getNotifications(userId: string): Promise<Notification[]>;
  getNotification(id: string, userId: string): Promise<Notification | undefined>;
  createNotification(notification: InsertNotification, userId: string): Promise<Notification>;
  updateNotification(id: string, notification: Partial<InsertNotification>, userId: string): Promise<Notification | undefined>;
  deleteNotification(id: string, userId: string): Promise<boolean>;
  markNotificationAsRead(id: string, userId: string): Promise<boolean>;
  markAllNotificationsAsRead(userId: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private sessions: Map<string, Session>;
  private categories: Map<string, Category>;
  private expenses: Map<string, Expense>;
  private budgets: Map<string, Budget>;
  private recurringPayments: Map<string, RecurringPayment>;
  private notifications: Map<string, Notification>;

  constructor() {
    this.users = new Map();
    this.sessions = new Map();
    this.categories = new Map();
    this.expenses = new Map();
    this.budgets = new Map();
    this.recurringPayments = new Map();
    this.notifications = new Map();
  }

  // General default categories to seed for new users
  private DEFAULT_CATEGORIES: Array<Partial<Category>> = [
    { name: 'Food', icon: 'Coffee', color: 'hsl(16, 90%, 58%)', isDefault: true, parentId: null as any },
    { name: 'Transport', icon: 'Car', color: 'hsl(200, 98%, 39%)', isDefault: true },
    { name: 'Entertainment', icon: 'Film', color: 'hsl(280, 87%, 65%)', isDefault: true },
    { name: 'Shopping', icon: 'ShoppingBag', color: 'hsl(340, 82%, 52%)', isDefault: true },
    { name: 'Bills', icon: 'Zap', color: 'hsl(38, 92%, 50%)', isDefault: true },
    { name: 'Health', icon: 'Heart', color: 'hsl(120, 61%, 50%)', isDefault: true },
    { name: 'Education', icon: 'GraduationCap', color: 'hsl(262, 52%, 47%)', isDefault: true },
    { name: 'Housing', icon: 'Home', color: 'hsl(210, 16%, 48%)', isDefault: true },
    { name: 'Savings', icon: 'Wallet', color: 'hsl(145, 63%, 40%)', isDefault: true },
    { name: 'Other', icon: 'MoreHorizontal', color: 'hsl(215, 20%, 65%)', isDefault: true },
  ];

  // User management
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async getUserById(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const user: User = {
      ...insertUser,
      id,
      password: hashedPassword,
      avatar: insertUser.avatar || null,
      defaultCurrency: insertUser.defaultCurrency || "INR",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.users.set(id, user);
    // Seed default categories for the new user
    for (const def of this.DEFAULT_CATEGORIES) {
      const catId = randomUUID();
      const category: Category = {
        id: catId,
        userId: id,
        name: def.name as string,
        icon: def.icon as string,
        color: def.color as string,
        parentId: (def as any).parentId || null,
        isDefault: true,
      };
      this.categories.set(catId, category);
    }
    return user;
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updated: User = { 
      ...user, 
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    if (updates.password) {
      updated.password = await bcrypt.hash(updates.password, 10);
    }
    this.users.set(id, updated);
    return updated;
  }

  async deleteUser(id: string): Promise<boolean> {
    return this.users.delete(id);
  }

  // Session management
  async createSession(insertSession: InsertSession): Promise<Session> {
    const id = randomUUID();
    const session: Session = {
      ...insertSession,
      id,
      createdAt: new Date().toISOString(),
    };
    this.sessions.set(session.token, session);
    return session;
  }

  async getSessionByToken(token: string): Promise<Session | undefined> {
    return this.sessions.get(token);
  }

  async deleteSession(token: string): Promise<boolean> {
    return this.sessions.delete(token);
  }

  async deleteUserSessions(userId: string): Promise<boolean> {
    const userSessions = Array.from(this.sessions.values()).filter(s => s.userId === userId);
    userSessions.forEach(session => this.sessions.delete(session.token));
    return true;
  }

  async getCategories(userId: string): Promise<Category[]> {
    return Array.from(this.categories.values()).filter(cat => cat.userId === userId);
  }

  // Seed default categories for an existing user if they have none
  async seedDefaultCategoriesForUser(userId: string): Promise<Category[]> {
    const existing = Array.from(this.categories.values()).filter(cat => cat.userId === userId);
    if (existing.length > 0) return existing;

    const created: Category[] = [];
    for (const def of this.DEFAULT_CATEGORIES) {
      const id = randomUUID();
      const category: Category = {
        id,
        userId,
        name: def.name as string,
        icon: def.icon as string,
        color: def.color as string,
        parentId: (def as any).parentId || null,
        isDefault: true,
      };
      this.categories.set(id, category);
      created.push(category);
    }
    return created;
  }

  async getCategory(id: string, userId: string): Promise<Category | undefined> {
    const category = this.categories.get(id);
    return category && category.userId === userId ? category : undefined;
  }

  async createCategory(insertCategory: InsertCategory, userId: string): Promise<Category> {
    const id = randomUUID();
    const category: Category = {
      id,
      userId,
      name: insertCategory.name,
      icon: insertCategory.icon,
      color: insertCategory.color,
      parentId: (insertCategory as any).parentId ?? null,
      isDefault: false,
    };
    this.categories.set(id, category);
    return category;
  }

  async updateCategory(id: string, updates: Partial<InsertCategory>, userId: string): Promise<Category | undefined> {
    const category = this.categories.get(id);
    if (!category || category.userId !== userId) return undefined;
    const updated: Category = { 
      ...category, 
      ...updates,
      parentId: (updates as any).parentId === undefined ? category.parentId : (updates as any).parentId,
    };
    this.categories.set(id, updated);
    return updated;
  }

  async deleteCategory(id: string, userId: string): Promise<boolean> {
    const category = this.categories.get(id);
    if (!category || category.userId !== userId) return false;
    return this.categories.delete(id);
  }

  async getExpenses(userId: string): Promise<Expense[]> {
    return Array.from(this.expenses.values()).filter(expense => expense.userId === userId);
  }

  async getExpense(id: string, userId: string): Promise<Expense | undefined> {
    const expense = this.expenses.get(id);
    return expense && expense.userId === userId ? expense : undefined;
  }

  async createExpense(insertExpense: InsertExpense, userId: string): Promise<Expense> {
    const id = randomUUID();
    const expense: Expense = {
      ...insertExpense,
      id,
      userId,
      amount: insertExpense.amount.toString(),
      currency: insertExpense.currency || "INR",
      notes: insertExpense.notes || null,
      tags: insertExpense.tags || null,
      isRecurring: false,
      recurringId: null,
      createdAt: new Date().toISOString(),
    };
    this.expenses.set(id, expense);
    return expense;
  }

  async updateExpense(id: string, updates: Partial<InsertExpense>, userId: string): Promise<Expense | undefined> {
    const expense = this.expenses.get(id);
    if (!expense || expense.userId !== userId) return undefined;

    const updated: Expense = {
      ...expense,
      ...updates,
      amount: updates.amount ? updates.amount.toString() : expense.amount,
    };
    this.expenses.set(id, updated);
    return updated;
  }

  async deleteExpense(id: string, userId: string): Promise<boolean> {
    const expense = this.expenses.get(id);
    if (!expense || expense.userId !== userId) return false;
    return this.expenses.delete(id);
  }

  async getBudgets(userId: string): Promise<Budget[]> {
    return Array.from(this.budgets.values()).filter(budget => budget.userId === userId);
  }

  async getBudget(id: string, userId: string): Promise<Budget | undefined> {
    const budget = this.budgets.get(id);
    return budget && budget.userId === userId ? budget : undefined;
  }

  async createBudget(insertBudget: InsertBudget, userId: string): Promise<Budget> {
    const id = randomUUID();
    const budget: Budget = {
      ...insertBudget,
      id,
      userId,
      amount: insertBudget.amount.toString(),
      currency: insertBudget.currency || "INR",
      categoryId: insertBudget.categoryId || null,
      isTotal: insertBudget.isTotal || false,
      startDate: typeof insertBudget.startDate === 'string' ? insertBudget.startDate : (insertBudget.startDate as Date).toISOString(),
      endDate: typeof insertBudget.endDate === 'string' ? insertBudget.endDate : (insertBudget.endDate as Date).toISOString(),
    };
    this.budgets.set(id, budget);
    return budget;
  }

  async updateBudget(id: string, updates: Partial<InsertBudget>, userId: string): Promise<Budget | undefined> {
    const budget = this.budgets.get(id);
    if (!budget || budget.userId !== userId) return undefined;

    const updated: Budget = {
      ...budget,
      ...updates,
      amount: updates.amount ? updates.amount.toString() : budget.amount,
      startDate: updates.startDate 
        ? (typeof updates.startDate === 'string' ? updates.startDate : (updates.startDate as Date).toISOString())
        : budget.startDate,
      endDate: updates.endDate 
        ? (typeof updates.endDate === 'string' ? updates.endDate : (updates.endDate as Date).toISOString())
        : budget.endDate,
    };
    this.budgets.set(id, updated);
    return updated;
  }

  async deleteBudget(id: string, userId: string): Promise<boolean> {
    const budget = this.budgets.get(id);
    if (!budget || budget.userId !== userId) return false;
    return this.budgets.delete(id);
  }

  async getRecurringPayments(userId: string): Promise<RecurringPayment[]> {
    return Array.from(this.recurringPayments.values()).filter(payment => payment.userId === userId);
  }

  async getRecurringPayment(id: string, userId: string): Promise<RecurringPayment | undefined> {
    const payment = this.recurringPayments.get(id);
    return payment && payment.userId === userId ? payment : undefined;
  }

  async createRecurringPayment(insertPayment: InsertRecurringPayment, userId: string): Promise<RecurringPayment> {
    const id = randomUUID();
    const payment: RecurringPayment = {
      ...insertPayment,
      id,
      userId,
      amount: insertPayment.amount.toString(),
      currency: insertPayment.currency || "INR",
      notes: insertPayment.notes || null,
      isActive: insertPayment.isActive || true,
      startDate: typeof insertPayment.startDate === 'string' ? insertPayment.startDate : (insertPayment.startDate as Date).toISOString(),
      nextDue: typeof insertPayment.nextDue === 'string' ? insertPayment.nextDue : (insertPayment.nextDue as Date).toISOString(),
    };
    this.recurringPayments.set(id, payment);
    return payment;
  }

  async updateRecurringPayment(id: string, updates: Partial<InsertRecurringPayment>, userId: string): Promise<RecurringPayment | undefined> {
    const payment = this.recurringPayments.get(id);
    if (!payment || payment.userId !== userId) return undefined;

    const updated: RecurringPayment = {
      ...payment,
      ...updates,
      amount: updates.amount ? updates.amount.toString() : payment.amount,
      startDate: updates.startDate 
        ? (typeof updates.startDate === 'string' ? updates.startDate : (updates.startDate as Date).toISOString())
        : payment.startDate,
      nextDue: updates.nextDue 
        ? (typeof updates.nextDue === 'string' ? updates.nextDue : (updates.nextDue as Date).toISOString())
        : payment.nextDue,
    };
    this.recurringPayments.set(id, updated);
    return updated;
  }

  async deleteRecurringPayment(id: string, userId: string): Promise<boolean> {
    const payment = this.recurringPayments.get(id);
    if (!payment || payment.userId !== userId) return false;
    return this.recurringPayments.delete(id);
  }

  // Notification management
  async getNotifications(userId: string): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(notification => notification.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getNotification(id: string, userId: string): Promise<Notification | undefined> {
    const notification = this.notifications.get(id);
    return notification && notification.userId === userId ? notification : undefined;
  }

  async createNotification(insertNotification: InsertNotification, userId: string): Promise<Notification> {
    const id = randomUUID();
    const notification: Notification = {
      ...insertNotification,
      id,
      userId,
      data: insertNotification.data || null,
      isRead: insertNotification.isRead || false,
      createdAt: new Date().toISOString(),
    };
    this.notifications.set(id, notification);
    return notification;
  }

  async updateNotification(id: string, updates: Partial<InsertNotification>, userId: string): Promise<Notification | undefined> {
    const notification = this.notifications.get(id);
    if (!notification || notification.userId !== userId) return undefined;

    const updated: Notification = { ...notification, ...updates };
    this.notifications.set(id, updated);
    return updated;
  }

  async deleteNotification(id: string, userId: string): Promise<boolean> {
    const notification = this.notifications.get(id);
    if (!notification || notification.userId !== userId) return false;
    return this.notifications.delete(id);
  }

  async markNotificationAsRead(id: string, userId: string): Promise<boolean> {
    const notification = this.notifications.get(id);
    if (!notification || notification.userId !== userId) return false;
    
    notification.isRead = true;
    this.notifications.set(id, notification);
    return true;
  }

  async markAllNotificationsAsRead(userId: string): Promise<boolean> {
    const userNotifications = Array.from(this.notifications.values())
      .filter(notification => notification.userId === userId && !notification.isRead);
    
    userNotifications.forEach(notification => {
      notification.isRead = true;
      this.notifications.set(notification.id, notification);
    });
    
    return true;
  }
}

export const storage = new MemStorage();
