import { storage } from "./storage";
import type { Budget, Expense, Category } from "@shared/schema";

export interface BudgetAlertData {
  budgetId: string;
  budgetName: string;
  spent: number;
  budget: number;
  percentage: number;
  categoryName?: string;
}

export async function checkBudgetAlerts(userId: string): Promise<void> {
  try {
    const [budgets, expenses, categories] = await Promise.all([
      storage.getBudgets(userId),
      storage.getExpenses(userId),
      storage.getCategories(userId),
    ]);

    const categoryMap = new Map(categories.map(cat => [cat.id, cat]));

    for (const budget of budgets) {
      const budgetExpenses = expenses.filter(expense => {
        const expenseDate = new Date(expense.date);
        const budgetStart = new Date(budget.startDate);
        const budgetEnd = new Date(budget.endDate);
        
        if (budget.categoryId) {
          return expense.categoryId === budget.categoryId && 
                 expenseDate >= budgetStart && 
                 expenseDate <= budgetEnd;
        } else {
          // Total budget
          return expenseDate >= budgetStart && expenseDate <= budgetEnd;
        }
      });

      const totalSpent = budgetExpenses.reduce((sum, expense) => sum + parseFloat(expense.amount), 0);
      const budgetAmount = parseFloat(budget.amount);
      const percentage = (totalSpent / budgetAmount) * 100;

      // Check if we need to create an alert
      if (percentage >= budget.alertThreshold) {
        const categoryName = budget.categoryId ? categoryMap.get(budget.categoryId)?.name : 'Total';
        const budgetName = budget.categoryId ? `${categoryName} Budget` : 'Total Budget';
        
        const alertData: BudgetAlertData = {
          budgetId: budget.id,
          budgetName,
          spent: totalSpent,
          budget: budgetAmount,
          percentage: Math.round(percentage),
          categoryName,
        };

        // Check if we already have an alert for this budget
        const existingNotifications = await storage.getNotifications(userId);
        const existingAlert = existingNotifications.find(notif => 
          notif.type === 'budget_alert' && 
          notif.data && 
          JSON.parse(notif.data).budgetId === budget.id &&
          !notif.isRead
        );

        if (!existingAlert) {
          let title: string;
          let message: string;

          if (percentage >= 100) {
            title = `🚨 Budget Exceeded: ${budgetName}`;
            message = `You've exceeded your ${budgetName} by ₹${(totalSpent - budgetAmount).toFixed(2)}. Total spent: ₹${totalSpent.toFixed(2)} of ₹${budgetAmount.toFixed(2)}.`;
          } else {
            title = `⚠️ Budget Alert: ${budgetName}`;
            message = `You've used ${Math.round(percentage)}% of your ${budgetName}. Spent: ₹${totalSpent.toFixed(2)} of ₹${budgetAmount.toFixed(2)}.`;
          }

          await storage.createNotification({
            type: 'budget_alert',
            title,
            message,
            data: JSON.stringify(alertData),
          }, userId);
        }
      }
    }
  } catch (error) {
    console.error('Error checking budget alerts:', error);
  }
}

export async function checkRecurringPaymentAlerts(userId: string): Promise<void> {
  try {
    const recurringPayments = await storage.getRecurringPayments(userId);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    for (const payment of recurringPayments) {
      if (!payment.isActive) continue;

      const nextDue = new Date(payment.nextDue);
      nextDue.setHours(0, 0, 0, 0);
      
      const daysUntilDue = Math.ceil((nextDue.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

      // Alert if due within 3 days
      if (daysUntilDue <= 3 && daysUntilDue >= 0) {
        const existingNotifications = await storage.getNotifications(userId);
        const existingAlert = existingNotifications.find(notif => 
          notif.type === 'recurring_due' && 
          notif.data && 
          JSON.parse(notif.data).paymentId === payment.id &&
          !notif.isRead
        );

        if (!existingAlert) {
          let title: string;
          let message: string;

          if (daysUntilDue === 0) {
            title = `💰 Due Today: ${payment.description}`;
            message = `Your recurring payment "${payment.description}" of ₹${payment.amount} is due today.`;
          } else if (daysUntilDue === 1) {
            title = `⏰ Due Tomorrow: ${payment.description}`;
            message = `Your recurring payment "${payment.description}" of ₹${payment.amount} is due tomorrow.`;
          } else {
            title = `📅 Due Soon: ${payment.description}`;
            message = `Your recurring payment "${payment.description}" of ₹${payment.amount} is due in ${daysUntilDue} days.`;
          }

          await storage.createNotification({
            type: 'recurring_due',
            title,
            message,
            data: JSON.stringify({
              paymentId: payment.id,
              amount: payment.amount,
              description: payment.description,
              nextDue: payment.nextDue,
              daysUntilDue,
            }),
          }, userId);
        }
      }
    }
  } catch (error) {
    console.error('Error checking recurring payment alerts:', error);
  }
}
