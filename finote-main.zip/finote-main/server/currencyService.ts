import { storage } from "./storage";
import type { CurrencyRate } from "@shared/schema";

export interface CurrencyInfo {
  code: string;
  name: string;
  symbol: string;
  flag: string;
}

export const SUPPORTED_CURRENCIES: CurrencyInfo[] = [
  { code: "INR", name: "Indian Rupee", symbol: "₹", flag: "🇮🇳" },
  { code: "USD", name: "US Dollar", symbol: "$", flag: "🇺🇸" },
  { code: "EUR", name: "Euro", symbol: "€", flag: "🇪🇺" },
  { code: "GBP", name: "British Pound", symbol: "£", flag: "🇬🇧" },
  { code: "JPY", name: "Japanese Yen", symbol: "¥", flag: "🇯🇵" },
  { code: "CAD", name: "Canadian Dollar", symbol: "C$", flag: "🇨🇦" },
  { code: "AUD", name: "Australian Dollar", symbol: "A$", flag: "🇦🇺" },
  { code: "CHF", name: "Swiss Franc", symbol: "CHF", flag: "🇨🇭" },
  { code: "CNY", name: "Chinese Yuan", symbol: "¥", flag: "🇨🇳" },
  { code: "SGD", name: "Singapore Dollar", symbol: "S$", flag: "🇸🇬" },
  { code: "AED", name: "UAE Dirham", symbol: "د.إ", flag: "🇦🇪" },
  { code: "SAR", name: "Saudi Riyal", symbol: "﷼", flag: "🇸🇦" },
];

export class CurrencyService {
  private static instance: CurrencyService;
  private rates: Map<string, number> = new Map();

  private constructor() {}

  static getInstance(): CurrencyService {
    if (!CurrencyService.instance) {
      CurrencyService.instance = new CurrencyService();
    }
    return CurrencyService.instance;
  }

  async getExchangeRate(fromCurrency: string, toCurrency: string): Promise<number> {
    if (fromCurrency === toCurrency) {
      return 1;
    }

    const rateKey = `${fromCurrency}_${toCurrency}`;
    
    // Check if we have a cached rate
    if (this.rates.has(rateKey)) {
      return this.rates.get(rateKey)!;
    }

    // For demo purposes, we'll use mock exchange rates
    // In a real app, you'd fetch from an API like exchangerate-api.com
    const mockRates: Record<string, number> = {
      'USD_INR': 83.0,
      'EUR_INR': 90.0,
      'GBP_INR': 105.0,
      'JPY_INR': 0.55,
      'CAD_INR': 61.0,
      'AUD_INR': 54.0,
      'CHF_INR': 92.0,
      'CNY_INR': 11.5,
      'SGD_INR': 61.5,
      'AED_INR': 22.6,
      'SAR_INR': 22.1,
    };

    // Add reverse rates
    Object.entries(mockRates).forEach(([key, rate]) => {
      const [from, to] = key.split('_');
      mockRates[`${to}_${from}`] = 1 / rate;
    });

    const rate = mockRates[rateKey] || 1;
    this.rates.set(rateKey, rate);

    return rate;
  }

  async convertAmount(amount: number, fromCurrency: string, toCurrency: string): Promise<number> {
    const rate = await this.getExchangeRate(fromCurrency, toCurrency);
    return amount * rate;
  }

  formatCurrency(amount: number, currency: string): string {
    const currencyInfo = SUPPORTED_CURRENCIES.find(c => c.code === currency);
    if (!currencyInfo) {
      return `${currency} ${amount.toFixed(2)}`;
    }

    // Format based on currency
    switch (currency) {
      case 'INR':
        return `₹${amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      case 'USD':
        return `$${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      case 'EUR':
        return `€${amount.toLocaleString('en-EU', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      case 'GBP':
        return `£${amount.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      case 'JPY':
        return `¥${amount.toLocaleString('ja-JP', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
      default:
        return `${currencyInfo.symbol}${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
  }

  getCurrencyInfo(currency: string): CurrencyInfo | undefined {
    return SUPPORTED_CURRENCIES.find(c => c.code === currency);
  }

  getAllCurrencies(): CurrencyInfo[] {
    return SUPPORTED_CURRENCIES;
  }
}

export const currencyService = CurrencyService.getInstance();
