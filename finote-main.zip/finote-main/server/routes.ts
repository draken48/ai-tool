import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { authenticateToken, optionalAuth, generateToken, type AuthenticatedRequest } from "./auth";
import { 
  insertUserSchema,
  insertCategorySchema,
  insertExpenseSchema,
  insertBudgetSchema,
  insertRecurringPaymentSchema,
  insertNotificationSchema
} from "@shared/schema";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { checkBudgetAlerts, checkRecurringPaymentAlerts } from "./budgetAlerts";
import { currencyService } from "./currencyService";

function convertToCSV(data: any): string {
  const { categories, expenses, budgets, recurringPayments } = data.data;
  
  let csv = 'Type,ID,Name/Description,Amount,Category,Date,Notes,Tags\n';
  
  // Export categories
  categories.forEach((cat: any) => {
    csv += `Category,${cat.id},"${cat.name}",,"${cat.name}",,,"${cat.icon}"\n`;
  });
  
  // Export expenses
  expenses.forEach((expense: any) => {
    const category = categories.find((c: any) => c.id === expense.categoryId);
    const tags = expense.tags ? expense.tags.join(';') : '';
    csv += `Expense,${expense.id},"${expense.description}",${expense.amount},"${category?.name || 'Unknown'}",${expense.date},"${expense.notes || ''}","${tags}"\n`;
  });
  
  // Export budgets
  budgets.forEach((budget: any) => {
    const category = budget.categoryId ? categories.find((c: any) => c.id === budget.categoryId) : null;
    csv += `Budget,${budget.id},"${budget.period} Budget",${budget.amount},"${category?.name || 'Total'}",${budget.startDate},"${budget.period}","${budget.alertThreshold}% threshold"\n`;
  });
  
  // Export recurring payments
  recurringPayments.forEach((payment: any) => {
    const category = categories.find((c: any) => c.id === payment.categoryId);
    csv += `Recurring,${payment.id},"${payment.description}",${payment.amount},"${category?.name || 'Unknown'}",${payment.nextDue},"${payment.notes || ''}","${payment.frequency}"\n`;
  });
  
  return csv;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post('/api/auth/register', async (req, res) => {
    try {
      const data = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(data.email);
      if (existingUser) {
        return res.status(400).json({ message: 'User already exists' });
      }

      const user = await storage.createUser(data);
      
      // Create session
      const token = generateToken();
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days
      await storage.createSession({
        userId: user.id,
        token,
        expiresAt: expiresAt.toISOString(),
      });

      res.status(201).json({
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
        },
        token,
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post('/api/auth/login', async (req, res) => {
    try {
      const { email, password } = z.object({
        email: z.string().email(),
        password: z.string().min(1),
      }).parse(req.body);

      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }

      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }

      // Create session
      const token = generateToken();
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days
      await storage.createSession({
        userId: user.id,
        token,
        expiresAt: expiresAt.toISOString(),
      });

      res.json({
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
        },
        token,
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post('/api/auth/logout', authenticateToken, async (req: AuthenticatedRequest, res) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    
    if (token) {
      await storage.deleteSession(token);
    }
    
    res.json({ message: 'Logged out successfully' });
  });

  app.get('/api/auth/me', authenticateToken, async (req: AuthenticatedRequest, res) => {
    res.json(req.user);
  });

  // Protected routes - all require authentication
  app.get('/api/categories', authenticateToken, async (req: AuthenticatedRequest, res) => {
    // If the user has no categories, seed them with defaults and return those
    const categoriesForUser = await storage.getCategories(req.user!.id);
    if (categoriesForUser.length === 0) {
      const seeded = await storage.seedDefaultCategoriesForUser(req.user!.id);
      return res.json(seeded);
    }

    res.json(categoriesForUser);
  });

  app.get('/api/categories/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
    const category = await storage.getCategory(req.params.id, req.user!.id);
    if (!category) {
      return res.status(404).json({ message: 'Category not found' });
    }
    res.json(category);
  });

  app.post('/api/categories', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const data = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(data, req.user!.id);
      res.status(201).json(category);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch('/api/categories/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      // if parentId is provided, validate it doesn't create a cycle
      const parentId = (req.body as any).parentId;
      if (parentId) {
        // walk up parents from parentId and ensure we never reach req.params.id
        let cur = parentId as string | null;
        const seen = new Set<string>();
        while (cur) {
          if (seen.has(cur)) break; // defensive
          if (cur === req.params.id) {
            return res.status(400).json({ message: 'Invalid parent: would create a cycle' });
          }
          seen.add(cur);
          const parent = await storage.getCategory(cur, req.user!.id);
          if (!parent) break;
          cur = parent.parentId as any || null;
        }
      }

      const category = await storage.updateCategory(req.params.id, req.body, req.user!.id);
      if (!category) {
        return res.status(404).json({ message: 'Category not found' });
      }
      res.json(category);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete('/api/categories/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
    const deleted = await storage.deleteCategory(req.params.id, req.user!.id);
    if (!deleted) {
      return res.status(404).json({ message: 'Category not found' });
    }
    res.status(204).send();
  });

  app.get('/api/expenses', authenticateToken, async (req: AuthenticatedRequest, res) => {
    const expenses = await storage.getExpenses(req.user!.id);
    res.json(expenses);
  });

  app.get('/api/expenses/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
    const expense = await storage.getExpense(req.params.id, req.user!.id);
    if (!expense) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    res.json(expense);
  });

  app.post('/api/expenses', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const data = insertExpenseSchema.parse(req.body);
      const expense = await storage.createExpense(data, req.user!.id);
      
      // Check for budget alerts after creating expense
      checkBudgetAlerts(req.user!.id).catch(console.error);
      
      res.status(201).json(expense);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch('/api/expenses/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const expense = await storage.updateExpense(req.params.id, req.body, req.user!.id);
      if (!expense) {
        return res.status(404).json({ message: 'Expense not found' });
      }
      res.json(expense);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete('/api/expenses/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
    const deleted = await storage.deleteExpense(req.params.id, req.user!.id);
    if (!deleted) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    res.status(204).send();
  });

  app.get('/api/budgets', authenticateToken, async (req: AuthenticatedRequest, res) => {
    const budgets = await storage.getBudgets(req.user!.id);
    res.json(budgets);
  });

  app.get('/api/budgets/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
    const budget = await storage.getBudget(req.params.id, req.user!.id);
    if (!budget) {
      return res.status(404).json({ message: 'Budget not found' });
    }
    res.json(budget);
  });

  app.post('/api/budgets', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const data = insertBudgetSchema.parse(req.body);
      const budget = await storage.createBudget(data, req.user!.id);
      res.status(201).json(budget);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch('/api/budgets/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const budget = await storage.updateBudget(req.params.id, req.body, req.user!.id);
      if (!budget) {
        return res.status(404).json({ message: 'Budget not found' });
      }
      res.json(budget);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete('/api/budgets/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
    const deleted = await storage.deleteBudget(req.params.id, req.user!.id);
    if (!deleted) {
      return res.status(404).json({ message: 'Budget not found' });
    }
    res.status(204).send();
  });

  app.get('/api/recurring-payments', authenticateToken, async (req: AuthenticatedRequest, res) => {
    const payments = await storage.getRecurringPayments(req.user!.id);
    res.json(payments);
  });

  app.get('/api/recurring-payments/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
    const payment = await storage.getRecurringPayment(req.params.id, req.user!.id);
    if (!payment) {
      return res.status(404).json({ message: 'Recurring payment not found' });
    }
    res.json(payment);
  });

  app.post('/api/recurring-payments', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const data = insertRecurringPaymentSchema.parse(req.body);
      const payment = await storage.createRecurringPayment(data, req.user!.id);
      res.status(201).json(payment);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch('/api/recurring-payments/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const payment = await storage.updateRecurringPayment(req.params.id, req.body, req.user!.id);
      if (!payment) {
        return res.status(404).json({ message: 'Recurring payment not found' });
      }
      res.json(payment);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete('/api/recurring-payments/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
    const deleted = await storage.deleteRecurringPayment(req.params.id, req.user!.id);
    if (!deleted) {
      return res.status(404).json({ message: 'Recurring payment not found' });
    }
    res.status(204).send();
  });

  // Data export/import routes
  app.get('/api/export', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const [categories, expenses, budgets, recurringPayments] = await Promise.all([
        storage.getCategories(userId),
        storage.getExpenses(userId),
        storage.getBudgets(userId),
        storage.getRecurringPayments(userId),
      ]);

      const exportData = {
        version: '1.0',
        exportDate: new Date().toISOString(),
        data: {
          categories,
          expenses,
          budgets,
          recurringPayments,
        },
      };

      const format = req.query.format as string || 'json';
      
      if (format === 'csv') {
        // Convert to CSV format
        const csvData = convertToCSV(exportData);
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="finote-export-${new Date().toISOString().split('T')[0]}.csv"`);
        res.send(csvData);
      } else {
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Content-Disposition', `attachment; filename="finote-export-${new Date().toISOString().split('T')[0]}.json"`);
        res.json(exportData);
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post('/api/import', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { data } = req.body;

      if (!data || !data.categories || !data.expenses || !data.budgets || !data.recurringPayments) {
        return res.status(400).json({ message: 'Invalid import data format' });
      }

      // Import categories first (they're referenced by other entities)
      const categoryMap = new Map();
      for (const category of data.categories) {
        const newCategory = await storage.createCategory({
          name: category.name,
          icon: category.icon,
          color: category.color,
        }, userId);
        categoryMap.set(category.id, newCategory.id);
      }

      // Import expenses
      for (const expense of data.expenses) {
        await storage.createExpense({
          amount: parseFloat(expense.amount),
          currency: expense.currency || "INR",
          description: expense.description,
          categoryId: categoryMap.get(expense.categoryId) || expense.categoryId,
          date: expense.date,
          notes: expense.notes,
          tags: expense.tags,
        }, userId);
      }

      // Import budgets
      for (const budget of data.budgets) {
        await storage.createBudget({
          categoryId: budget.categoryId ? categoryMap.get(budget.categoryId) : undefined,
          amount: parseFloat(budget.amount),
          currency: budget.currency || "INR",
          period: budget.period,
          startDate: budget.startDate,
          endDate: budget.endDate,
          alertThreshold: budget.alertThreshold,
          isTotal: budget.isTotal,
        }, userId);
      }

      // Import recurring payments
      for (const payment of data.recurringPayments) {
        await storage.createRecurringPayment({
          amount: parseFloat(payment.amount),
          currency: payment.currency || "INR",
          description: payment.description,
          categoryId: categoryMap.get(payment.categoryId) || payment.categoryId,
          frequency: payment.frequency,
          startDate: payment.startDate,
          nextDue: payment.nextDue,
          isActive: payment.isActive,
          notes: payment.notes,
        }, userId);
      }

      res.json({ message: 'Data imported successfully' });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Notification routes
  app.get('/api/notifications', authenticateToken, async (req: AuthenticatedRequest, res) => {
    const notifications = await storage.getNotifications(req.user!.id);
    res.json(notifications);
  });

  app.get('/api/notifications/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
    const notification = await storage.getNotification(req.params.id, req.user!.id);
    if (!notification) {
      return res.status(404).json({ message: 'Notification not found' });
    }
    res.json(notification);
  });

  app.post('/api/notifications', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const data = insertNotificationSchema.parse(req.body);
      const notification = await storage.createNotification(data, req.user!.id);
      res.status(201).json(notification);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch('/api/notifications/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const notification = await storage.updateNotification(req.params.id, req.body, req.user!.id);
      if (!notification) {
        return res.status(404).json({ message: 'Notification not found' });
      }
      res.json(notification);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete('/api/notifications/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
    const deleted = await storage.deleteNotification(req.params.id, req.user!.id);
    if (!deleted) {
      return res.status(404).json({ message: 'Notification not found' });
    }
    res.status(204).send();
  });

  app.patch('/api/notifications/:id/read', authenticateToken, async (req: AuthenticatedRequest, res) => {
    const success = await storage.markNotificationAsRead(req.params.id, req.user!.id);
    if (!success) {
      return res.status(404).json({ message: 'Notification not found' });
    }
    res.json({ message: 'Notification marked as read' });
  });

  app.patch('/api/notifications/read-all', authenticateToken, async (req: AuthenticatedRequest, res) => {
    await storage.markAllNotificationsAsRead(req.user!.id);
    res.json({ message: 'All notifications marked as read' });
  });

  // Manual budget check endpoint
  app.post('/api/check-alerts', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      await Promise.all([
        checkBudgetAlerts(req.user!.id),
        checkRecurringPaymentAlerts(req.user!.id),
      ]);
      res.json({ message: 'Budget alerts checked successfully' });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Currency routes
  app.get('/api/currencies', (req, res) => {
    res.json(currencyService.getAllCurrencies());
  });

  app.get('/api/currencies/:code', (req, res) => {
    const currency = currencyService.getCurrencyInfo(req.params.code);
    if (!currency) {
      return res.status(404).json({ message: 'Currency not found' });
    }
    res.json(currency);
  });

  app.get('/api/currencies/convert', async (req, res) => {
    try {
      const { amount, from, to } = req.query;
      
      if (!amount || !from || !to) {
        return res.status(400).json({ message: 'Amount, from, and to parameters are required' });
      }

      const convertedAmount = await currencyService.convertAmount(
        parseFloat(amount as string),
        from as string,
        to as string
      );

      res.json({
        originalAmount: parseFloat(amount as string),
        originalCurrency: from,
        convertedAmount,
        convertedCurrency: to,
        rate: await currencyService.getExchangeRate(from as string, to as string),
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // OpenAI Assistant proxy endpoint
  app.post('/api/assistant', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const apiKey = process.env.OPENAI_API_KEY;

      const body = req.body || {};
      // Accept either { messages: [{role, content}], prompt: 'text' }
      let messages: Array<{ role: string; content: string }> = [];
      if (Array.isArray(body.messages)) {
        messages = body.messages;
      } else if (typeof body.prompt === 'string') {
        messages = [{ role: 'user', content: body.prompt }];
      } else {
        return res.status(400).json({ message: 'Missing prompt or messages in request body' });
      }

      // Prepend a helpful system prompt
      const systemPrompt = { role: 'system', content: 'You are Finote, a helpful personal finance assistant. Keep answers concise and friendly.' };
      const payload = {
        model: 'gpt-3.5-turbo',
        messages: [systemPrompt, ...messages],
        max_tokens: 800,
        temperature: 0.2,
      };

      // If no API key is configured, provide a small local fallback that tries to match
      // the prompt to a category name present in the user's categories. This keeps
      // the assistant feature usable in development without requiring OpenAI.
      if (!apiKey) {
        // expect a simple single-user prompt where the user's message contains the
        // expense description. We'll attempt to find a category whose name is contained
        // in the prompt (case-insensitive). If found, return the category id.
        const prompt = (messages && messages.length > 0) ? messages[messages.length - 1].content : '';
        // load categories for this user from storage
        const cats = await storage.getCategories(req.user!.id);
        const lower = prompt.toLowerCase();
        let matchedId: string | null = null;
        for (const c of cats) {
          if (c.name && lower.includes(c.name.toLowerCase())) {
            matchedId = c.id;
            break;
          }
        }

        if (matchedId) {
          return res.json({ reply: matchedId, raw: { fallback: true } });
        }

        // no confident match
        return res.json({ reply: 'none', raw: { fallback: true } });
      }

      const resp = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify(payload),
      });

      if (!resp.ok) {
        const text = await resp.text();
        return res.status(resp.status).json({ message: text });
      }

      const data = await resp.json();
      const assistantMessage = data?.choices?.[0]?.message?.content ?? '';
      res.json({ reply: assistantMessage, raw: data });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
